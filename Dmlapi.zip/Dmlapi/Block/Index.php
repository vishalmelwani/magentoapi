<?php
class Grp_Dmlapi_Block_Index extends Mage_Core_Block_Template
{
	
	public function _construct()
    {			
	    parent::_construct();
		 
    } 
}

