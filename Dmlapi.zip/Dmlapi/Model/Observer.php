<?php

    class Grp_Dmlapi_Model_Observer
    {
    	public function checkoutCartProductAddAfter(Varien_Event_Observer $observer)
    	{

    		$product = $observer->getEvent()->getProduct();
	        $quote = Mage::getModel('checkout/cart')->getQuote();
	        //echo "<pre>";print_r($quote);exit;
	        $quoteItem = $quote->getItemByProduct( $product );
    	}  
    }