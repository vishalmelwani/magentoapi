<?php
    class Grp_Dmlapi_Model_Mysql4_Dmlapi_Collection extends Mage_Core_Model_Mysql4_Collection_Abstract
    {

		public function _construct(){
			$this->_init("dmlapi/dmlapi");
		}

		

    }
	 