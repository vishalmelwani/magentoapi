   
<?php
class Grp_Dmlapi_Helper_Data extends Mage_Core_Helper_Abstract
{
	public function updateIsfranchiseeCustom($orderId,$customerId){
		$order = Mage::getModel('sales/order')->load($orderId);
		$customer = Mage::getModel('customer/customer')->load($customerId);
    	$groupId = $customer->getGroupId();
        $group = Mage::getModel('customer/group')->load($groupId);

        $orderIncrId = $order->getIncrementId();
        $ActincrementId = $order->getIncrementId();
        $orderData = Mage::getModel('sales/order')->loadByIncrementId($ActincrementId);
        if($group->getCode() == 'DML Group'){

            $order_collection = Mage::getModel('sales/order')->getCollection()->addFieldToFilter('dmlstore_order_increment_id', array('neq' => ''));
            $order_collection->setOrder('entity_id','desc');
            $order_collection->setPageSize(1);
            $ordObj = $order_collection->getData();
            //echo "<pre>";print_r($ordObj);exit;
            if(count($ordObj) > 0){
                $onlynumber = str_replace('DML','33',$ordObj[0]['dmlstore_order_increment_id']);
                $newDmlstoreIncrId = str_replace('33','DML',($onlynumber+1));               
            }else{
                $newDmlstoreIncrId = str_replace(substr($orderData->getIncrementId(), 0, 2),'DML',$orderData->getIncrementId());
            }
            $orderData->setDmlstoreOrderIncrementId($newDmlstoreIncrId);
            $orderData->setDmlstoreUser(1);
            Mage::getSingleton("checkout/session")->getQuote()->setDmlstoreUser(1)->save();
            $orderData->save();
            // Mage::getSingleton('checkout/session')->clear(); // Removed // [[CUSTOM]] // For Shopping Cart empty issue
            foreach( Mage::getSingleton('checkout/session')->getQuote()->getItemsCollection() as $item ){
                Mage::getSingleton('checkout/cart')->removeItem( $item->getId() )->save();
            }
        
        } else {
            $lastUrl = Mage::getModel('core/session')->getLastUrl();
            $orderfrom = Mage::registry('order_From');
            if(preg_match("#/mystock/index/#", $lastUrl) || preg_match("#/oi/ajax/#", $lastUrl)){
                $urlFlag = 1;
            }else{
                
                $urlFlag = 0;
            }
            if ($urlFlag == 0) {
                $orderfrom = Mage::registry('order_From');
                if($orderfrom == 'mystockorder')
                {
                    $urlFlag = 1;
                }               
            }
            
            $orderData->setFranchiseOrderIncrementId(null);
            $orderData->setIsfranchisee(0);
            $orderData->setIsFranchise(0);          
            $orderData->save();
            
            Mage::unregister('order_From');
            if ($urlFlag == 0) {
                
                $order_collection = Mage::getModel('sales/order')->getCollection()->addFieldToFilter('franchise_order_increment_id', array('neq' => ''));
                $order_collection->setOrder('entity_id','desc');
                $order_collection->setPageSize(1);
                $ordObj = $order_collection->getData();
                if(count($ordObj) > 0){
                    $newFranchiseIncrId = $ordObj[0]['franchise_order_increment_id']+1;
                }else{
                    $newFranchiseIncrId = str_replace(substr($orderData->getIncrementId(), 0, 2),'11',$orderData->getIncrementId());
                }
                $orderData->setFranchiseOrderIncrementId($newFranchiseIncrId);
                $orderData->setIsfranchisee(1);
                $orderData->setIsFranchise(1);
                Mage::getSingleton("checkout/session")->getQuote()->setIsfranchisee(1)->save();
                Mage::getSingleton("checkout/session")->getQuote()->setIsFranchise(1)->save();
                $orderData->save();
                          
            }else{  
                Mage::getSingleton("checkout/session")->getQuote()->setIsfranchisee(0)->save();
                Mage::getSingleton("checkout/session")->getQuote()->setIsFranchise(0)->save();
                $orderData->setFranchiseOrderIncrementId(null);
                $orderData->setIsfranchisee(0);
                $orderData->setIsFranchise(0);          
                $orderData->save();
            }
            
        }
        return true;
	}

    public function requireauth() {
        $AUTH_USER = 'dealermela';
        $AUTH_PASS = '4FgTc&8mbv"D$6eW';
        header('Cache-Control: no-cache, must-revalidate, max-age=0');
        $has_supplied_credentials = !(empty($_SERVER['PHP_AUTH_USER']) && empty($_SERVER['PHP_AUTH_PW']));
        $is_not_authenticated = (
            !$has_supplied_credentials ||
            $_SERVER['PHP_AUTH_USER'] != $AUTH_USER ||
            $_SERVER['PHP_AUTH_PW']   != $AUTH_PASS
        );
        if ($is_not_authenticated) {
            header('HTTP/1.1 401 Authorization Required');
            header('WWW-Authenticate: Basic realm="Access denied"');
            return false;
            exit;
            
        }else{
            return true;
        }
    }
} 