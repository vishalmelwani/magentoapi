<?php
class Grp_Dmlapi_DownloadproductController extends Mage_Core_Controller_Front_Action{
	
	public function IndexAction() {     
      
        echo "in dml api customers";exit;       
    }

    public function DownloadAction()
    {
    	$customerId = $this->getRequest()->getParam('customer_id');
    	$getCustomer =  Mage::getModel('customer/customer')->load($customerId);
    	$productId = $this->getRequest()->getParam('product_id');
    	$_productsCollection = Mage::getModel('catalog/product')->load($productId);
    	if(count($_productsCollection->getData()) > 0)
    	{
	    	if ($_productsCollection->getTypeId() == 'configurable') {
				
				$conf = Mage::getModel('catalog/product_type_configurable')->setProduct($_productsCollection);
				$simple_collection = $conf->getUsedProductCollection()->addAttributeToSelect('*');
				foreach ($simple_collection as $simple_coll) {
					$extractskus = $simple_coll->getSku();
					if (strpos($extractskus, '14K Yellow Gold') !== false) 
					{	
						$FinalProductId =  $simple_coll->getEntityId();

					}
				}
			 }
			 else {
	    			$FinalProductId  = $_productsCollection->getEntityId();
	    			
	    	}
	    	$productIds = $getCustomer->getDownloadProducts();
	    	if(empty($productIds)) {
		   		$prids = array();	
		   	} else {
		   		$prids = explode(',', $productIds);
		   	}
   			if(count($prids) > 0)
		   	{ 
		   	 $getOriginalvalue = $getCustomer->getDownloadProducts() .',' . $FinalProductId;
		   	 $getCustomer->setDownloadProducts($getOriginalvalue)->save();
		   	}
		   	else
		   	{
		   	 	$getOriginalvalue = $FinalProductId;
		   	 	$getCustomer->setDownloadProducts($getOriginalvalue)->save();
			}

			echo json_encode(array('status'=>'success','product_id'=>$FinalProductId,'customer_id'=>$customerId));exit;
	    }
	    else
	    {
	    	echo json_encode(array('status'=>'failure','customer_id'=>$customerId));exit;	
	    }
    }

   		   

    public function DownloadViewAction()
    {
    	$pagesize = $this->getRequest()->getParam('pagesize');
    	$customerId = $this->getRequest()->getParam('customer_id');
    	$customerData =  Mage::getModel('customer/customer')->load($customerId);
     	
     $productIds =  $customerData->getDownloadProducts();
     $productIds_deleted =  $customerData->getDeletedProducts();
     $pids_downloaded = array_reverse(explode(',', $productIds));
     $pids_deleted = explode(',', $productIds_deleted);
     if(empty($productIds_deleted))
     {
        $FnlProductArray = $pids_downloaded;
     }
     if(empty($productIds))
     {
        $FnlProductArray = $pids_deleted;
     }
     if((!empty($productIds)) && (!empty($productIds_deleted)))
     {
        $FnlProductArray = array_merge($pids_downloaded, $pids_deleted);
     }

		$allDetail =  array();
	   if(count($FnlProductArray) > 0) { 
	   $col = Mage::getModel('catalog/product')->getcollection()->addAttributeToSelect('*')->addAttributeToFilter('entity_id', array('in' =>  $FnlProductArray))->setPageSize(20)->setCurPage($pagesize);

	    	if(($col->getSize()+20) >= ($pagesize*20)){
	    	foreach ($col as $_product) { 
	    		$PrdId = $_product->getEntityId();
	    		$_product = Mage::getModel('catalog/product')->load($PrdId);
	    		 $Sku = $_product->getData('sku');
	             $onlyskuArr = explode(' ', $Sku);
	             $quality = $_product->getData('rts_stone_quality');
	              if($quality == '')
                 {
                    $quality = 'SI-IJ';
                 }
                  $StoneDetail = $quality;
	              $pid = $_product->getId(); 
	              $mweight = round(Mage::helper('metal')->getExactMetalWeight($pid), 2);
	              $MetalDeatil  = round($mweight, 2).'gms';
	              $Carat = $onlyskuArr[1];
	              $diamondweight = Mage::helper('stone')->getSideStoneData($pid,$quality);
	              $DiamondWeight = $diamondweight['totalweight'][0].'ct';
	              $price = floor($_product->getData('custom_price'));
				  $image = Mage::helper('catalog/image')->init($_product, 'small_image')->keepFrame(false)->resize(300); 
	              $urlIm = $image->__toString();
	              /*[[get flag which products are deleted]]*/
	              $flag = 0;
	              if(in_array($pid,$pids_deleted))
	              {	
					$flag = 1;
	              }
	              $allDetail[] = array('product_id'=>$PrdId,'Sku'=>$Sku,'StoneDetail'=>$StoneDetail,'MetalDeatil'=>$MetalDeatil,'Carat'=>$Carat,'DiamondWeight'=>$DiamondWeight,'price'=>$price,'image'=>$urlIm,'flag'=>$flag);
	        	}	
			}else{
						$allDetail= [];
					}
			if(!empty($allDetail)) {
			 echo json_encode(array('status'=>'success','customer_id'=>$customerId,'data'=>$allDetail));exit;
         	}
         	else {
	    	echo json_encode(array('status'=>'failure','customer_id'=>$customerId,'data'=>$allDetail));exit;	
	   		 }
	    }
	    else
	    {
	    	echo json_encode(array('status'=>'failure','customer_id'=>$customerId,'data'=>$allDetail));exit;	
	    }
    }

    public function DownloadImageAction()
    {
    	$pids = $this->getRequest()->getParam('product_id');
    	$Price = $this->getRequest()->getParam('price');
    	$customerId = $this->getRequest()->getParam('customer_id');

    	if(!empty($pids))
    	{

	       $model = Mage::getModel("catalog/product");
		   $filesArr = array();
		   $proImgs = array();
		   $_product =Mage::getModel("catalog/product")->load($pids);
		   if($_product->getData('small_image') != '')
			{
				$img = $_product->getData('small_image');
			}
			else
			{
				$img =  'placeholder/default/def_2.png';
			}
			$prdid = $_product->getData('entity_id');
			$quality  = $_product->getData('rts_stone_quality');
			if($quality == '')
            {
                $quality = 'SI-IJ';
            }
			$prc = floor($_product->getData('custom_price'));
			$price = Mage::getModel('directory/currency')->format($prc,array('display'=>Zend_Currency::NO_SYMBOL),false);
			$name = $_product->getData('entity_id');
			$metalweight = round(Mage::helper('metal')->getExactMetalWeight($prdid), 2);					
			$sku = $_product->getData('sku');
			$onlyskuArr = explode(' ', $sku);
			$onlysku = $onlyskuArr[0];
			$metalquality = $onlyskuArr[1];
			$diamondweight = Mage::helper('stone')->getSideStoneData($prdid,$quality);
			$filesArr[] = $img;	 
			$image = Mage::getBaseDir().'/media/catalog/product/'.$img;
			$fontSize =20;
			$image_width = 200;
			$certified = "IGI CERTIFIED";
			if($Price == '0')
			{	
			$text = "GWT   ".$metalweight.' '.$metalquality.'|'.'DWT   '.$diamondweight['totalweight'][0].' '.$quality.'|'.'SKU   '.$onlysku.'|'.$certified;
			}
			if($Price == '1')
			{
				$text = "GWT   ".$metalweight.' '.$metalquality.'|'.'DWT   '.$diamondweight['totalweight'][0].' '.$quality.'|'.'PRICE '.$price.'|'.'SKU   '.$onlysku.'|'.$certified;
			}
			$lines = explode("|", $text);
			$xPosition = 50;
			$yPosition = 850;
			if($_product->getData('small_image') != '')
			{
				$newImg = imagecreatefromjpeg($image);
			}
			else
			{
				$newImg = imagecreatefrompng($image);
			}
			
			$fontColor = imagecolorallocate($newImg, 255, 255, 255);
			$i = $yPosition;
			$line_height = 25;
			$font= Mage::getBaseDir().'/'.'Myriad_Pro_Regular.ttf';
			foreach($lines as $line){
				imagettftext($newImg,$fontSize,0,$xPosition,$i, $fontColor, $font, $line);
		        $i += $line_height;
		    }
		    $url = Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_WEB);
			if($Price == '0')
		    {
				imagejpeg($newImg,'ApiDownloadImages/'.$name.'_wop.jpg');
				imagedestroy($newImg);
				$PrdImage = $name.'_wop.jpg';
				$path = $url.'ApiDownloadImages/'.$PrdImage;
			}
			if($Price == '1')
			{
				imagejpeg($newImg,'ApiDownloadImages/'.$name.'_wp.jpg');
				imagedestroy($newImg);
				$PrdImage = $name.'_wp.jpg';
				$path = $url.'ApiDownloadImages/'.$PrdImage;
			}
			echo json_encode(array('status'=>'success','customer_id'=>$customerId,'image'=>$path,'product_id'=>$pids));exit;
	    }
    	else
    	{
    		echo json_encode(array('status'=>'failure','customer_id'=>$customerId,'product_id'=>$pids));exit;
    	}	
    }

    public function DeleteProductAction()
    {	
    	 $id = $this->getRequest()->getParam('product_id');
    	 $customerId = $this->getRequest()->getParam('customer_id');
		 $ids = array();	
   	     $ids[] = $id; 
   		 $getCustomer =  Mage::getModel('customer/customer')->load($customerId);
   		 
   	 	 $productIds =  $getCustomer->getDownloadProducts();
   	 	 $prids = explode("," ,$productIds);
   	 	 if (in_array($id, $prids))
   	 	 {
   	 	 	$prdarry = array_diff($prids,$ids);
   	 	 	$products  = implode(",",$prdarry);
   	 	 	$getCustomer->setDownloadProducts($products)->save();
   	 	 	/*[[Add Product]]*/
	   		 $productIds = $getCustomer->getDeletedProducts();
		   	if(empty($productIds)) {
		   		$prids = array();	
		   	} else {
		   		$prids = explode(',', $productIds);
		   	}
			
			if(count($prids) > 0)
		   	{ 
		   	 $getOriginalvalue = $getCustomer->getDeletedProducts() .',' . $id;
		   	 $getCustomer->setDeletedProducts($getOriginalvalue)->save();
		   	}
		   	else
		   	{
		   	 	$getOriginalvalue = $id;
		   	 	$getCustomer->setDeletedProducts($getOriginalvalue)->save();
			}
			/*[[Add Product]]*/
   	 	 	echo json_encode(array('status'=>'success','customer_id'=>$customerId,'product_id'=>$id));exit;
		 }
   	 	 else
   	 	 {
   	 	 	echo json_encode(array('status'=>'failure','customer_id'=>$customerId,'product_id'=>$id));exit;
   	 	 }
   	 }

   	 public function DeleteAllProductAction11()
   	 {
   	 	$customerId = $this->getRequest()->getParam('customer_id');
		if(!empty($customerId)) {
			if($this->getRequest()->getParam('product_ids')) 
			{
				$ids = $this->getRequest()->getParam('product_ids');
				if(empty($ids))
				{
					$Pids = array();
				}
				else {
					$Pids = explode("," ,$ids);
				}
				$getCustomer =  Mage::getModel('customer/customer')->load($customerId);
				   	 	$productIds =  $getCustomer->getDownloadProducts();
				   	 	$prids = explode("," ,$productIds);
				   	 	$prdarry = array_diff($prids,$Pids);
				   	 	$products  = implode(",",$prdarry);
		   		if(count($Pids) > 0)
			   	{
			   			$getCustomer =  Mage::getModel('customer/customer')->load($customerId);
				   	 	$productIds =  $getCustomer->getDownloadProducts();
				   	 	$prids = explode("," ,$productIds);
				   	 	$prdarry = array_diff($prids,$Pids);
				   	 	$products  = implode(",",$prdarry);
				   	 	$getCustomer->setDownloadProducts($products)->save();
			   	}
			}
			else
			{

					$getCustomer = Mage::getModel('customer/customer')->load($customerId);
					$getCustomer->setDownloadProducts("")->save();
			}
			echo json_encode(array('status'=>'success','customer_id'=>$customerId));exit;
		}
		else
		{
			echo json_encode(array('status'=>'failure','customer_id'=>$customerId));exit;
		}
	}

	public function DeleteAllProductAction()
    {
   	 	$customerId = $this->getRequest()->getParam('customer_id');
   	 	$getCustomer =  Mage::getModel('customer/customer')->load($customerId);
   	 	$ids = $this->getRequest()->getParam('product_ids');
   	 	if(empty($ids))
		{
			$Pids = array();
		}
		else {
			$Pids = explode("," ,$ids);
		}
		if(!empty($customerId)) {
			

				/*[[Set product in deleted  attribute]]*/
				    $productIds = $getCustomer->getDeletedProducts();
				   	if(empty($productIds)) {
				   		$prids = array();	
				   	} else {
				   		$prids = explode(',', $productIds);
				   	}
					if(count($prids) > 0)
				   	{
				   		if(count($Pids) > 0) 
				   		{        
				   			     $prdarry = array_diff($Pids,$prids);
					   	 		 $products  = implode(",",$prdarry);
								 $getOriginalvalue = $getCustomer->getDeletedProducts() .',' . $products;
							   	 $getCustomer->setDeletedProducts($getOriginalvalue)->save();
					   	}
					   	else
					   	{
								$fnl_pids =  $getCustomer->getDownloadProducts();
								$fnl_pids_array = explode(",",$fnl_pids);
								$prdarry = array_diff($fnl_pids_array,$prids);
				   	 			$products  = implode(",",$prdarry);
				   	 			$getOriginalvalue = $getCustomer->getDeletedProducts() .',' . $products;
				   	 			$getCustomer->setDeletedProducts(rtrim($getOriginalvalue,','))->save();
						}
				   	}
				   	else
				   	{
				   		if(count($Pids) > 0) 
				   		{
							$prdarry = array_diff($Pids,$prids);
				   	 		$products  = implode(",",$prdarry);
							$getOriginalvalue = $products;
					   	 	$getCustomer->setDeletedProducts(rtrim($getOriginalvalue,','))->save();
						}
						else 
						{
						   $fnl_pids = $getCustomer->getDownloadProducts();
				   	 	   $getOriginalvalue = $fnl_pids;
				   	 	   $getCustomer->setDeletedProducts($getOriginalvalue)->save();
						}
				   	}
				/*[[Set product in deleted  attribute]]*/
				
				/*[[Remove product in download attribute]]*/
				
				if(count($Pids) > 0)
			   	{
			   			
				   	 	$productIds =  $getCustomer->getDownloadProducts();
				   	 	$prids = explode("," ,$productIds);
				   	 	$prdarry = array_diff($prids,$Pids);
				   	 	$products  = implode(",",$prdarry);
				   	 	$getOriginalvalue = $products;
				   	 	$getCustomer->setDownloadProducts(rtrim($getOriginalvalue,','))->save();
			   	}
			   	/*[[Remove product in download attribute]]*/
			   	else
				{

					$getCustomer = Mage::getModel('customer/customer')->load($customerId);
					$getCustomer->setDownloadProducts("")->save();
				}
				echo json_encode(array('status'=>'success','customer_id'=>$customerId));exit;
		}
		else
		{
			echo json_encode(array('status'=>'failure','customer_id'=>$customerId));exit;
		}
	}


	public function DownloadAllImageAction()
   	{
   			 $customerId = $this->getRequest()->getParam('customer_id'); 
   			 if($customerId)
    		 {
			 $WithWithoutPrice =$this->getRequest()->getParam('price'); 
			 $productIds_Param =$this->getRequest()->getParam('product_ids');
			 if(!empty($productIds_Param))
			 {
			 	$productIds = $productIds_Param;
			 }
			 else
			 {
			 	$getCustomer =  Mage::getModel('customer/customer')->load($customerId);
				$productIds =  $getCustomer->getDownloadProducts();
			 }
			 $pids = explode(',', $productIds);
			 $pidsArray = explode(',', $productIds);
			 $model = Mage::getModel("catalog/product");
			 $filesArr = array();
			 $proImgs = array();
	    
			 foreach ($pids as $pids) {
				$_product =Mage::getModel("catalog/product")->load($pids);
				if($_product->getData('small_image') != '')
				{
					$img = $_product->getData('small_image');
				}
				else
				{
					$img =  'placeholder/default/def_2.png';
				}
				$prdid = $_product->getData('entity_id');
				$quality  = $_product->getData('rts_stone_quality');
				if($quality == '')
                {
                    $quality = 'SI-IJ';
                }
				$price = $prc = floor($_product->getData('custom_price'));
				$price = Mage::getModel('directory/currency')->format($prc,array('display'=>Zend_Currency::NO_SYMBOL),false);
				$name = $_product->getData('entity_id');
				$metalweight = round(Mage::helper('metal')->getExactMetalWeight($prdid), 2);
				$sku = $_product->getData('sku');
				$onlyskuArr = explode(' ', $sku);
				$onlysku = $onlyskuArr[0];
				$metalquality = $onlyskuArr[1];
				$diamondweight = Mage::helper('stone')->getSideStoneData($prdid,$quality);
				$filesArr[] = $img;	 
				$image = Mage::getBaseDir().'/media/catalog/product/'.$img;
				$fontSize =20;
				$image_width = 200;
				$certified = "IGI CERTIFIED";
				if($WithWithoutPrice == '0')
				{	
				$text = "GWT   ".$metalweight.' '.$metalquality.'|'.'DWT   '.$diamondweight['totalweight'][0].' '.$quality.'|'.'SKU     '.$onlysku.'|'.$certified;
				}
				if($WithWithoutPrice == '1')
				{
					$text = "GWT   ".$metalweight.' '.$metalquality.'|'.'DWT   '.$diamondweight['totalweight'][0].' '.$quality.'|'.'PRICE   '.$price.'|'.'SKU     '.$onlysku.'|'.$certified;
				}
				$lines = explode("|", $text);
				$xPosition = 50;
				$yPosition = 850;
				if($_product->getData('small_image') != '')
				{
					$newImg = imagecreatefromjpeg($image);
				}
				else
				{
					$newImg = imagecreatefrompng($image);
				}
				$fontColor = imagecolorallocate($newImg, 255, 255, 255);
				$i = $yPosition;
				$line_height = 25;
				$font= Mage::getBaseDir().'/'.'Myriad_Pro_Regular.ttf';
				foreach($lines as $line){
					//imagestring($newImg, $font, $xPosition, $i, $line, $fontColor);
					imagettftext($newImg,$fontSize,0,$xPosition,$i, $fontColor, $font, $line);
			        $i += $line_height;
			    }
				$url = Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_WEB);
				if($WithWithoutPrice == '0')
			    {
					imagejpeg($newImg,'ApiDownloadImages/'.$name.'_wop.jpg');
					imagedestroy($newImg);
					$PrdImage = $name.'_wop.jpg';
					$path[] = $url.'ApiDownloadImages/'.$PrdImage;
				}
				if($WithWithoutPrice == '1')
				{
					imagejpeg($newImg,'ApiDownloadImages/'.$name.'_wp.jpg');
					imagedestroy($newImg);
					$PrdImage = $name.'_wp.jpg';
					$path[] = $url.'ApiDownloadImages/'.$PrdImage;
				}
			}
		echo json_encode(array('status'=>'success','customer_id'=>$customerId,'image'=>$path));exit;
	    }
    	else
    	{
    		echo json_encode(array('status'=>'failure','customer_id'=>$customerId));exit;
    	}	
	}
}
