<?php
class Grp_Dmlapi_AddtocartController extends Mage_Core_Controller_Front_Action{

    public function setaddressesAction(){
        $customerId = $this->getRequest()->getParam('customer_id');
        $addressId = $this->getRequest()->getParam('address_id');
        $flag_shipping = $this->getRequest()->getParam('flag_shipping');
        $customerscoll = Mage::getModel('customer/customer')->load($customerId);
        $alldata = $customerscoll->getPrimaryBillingAddress();
        $country = Mage::getModel('directory/country');
        if ($addressId) {
            $existsAddress = $customerscoll->getAddressById($addressId);
            if ($existsAddress->getId() && $existsAddress->getCustomerId() == $customerscoll->getId()) {
                $address = $existsAddress;
            }
        }
        if($flag_shipping == "billing"){
            $address->setCustomerId($customerscoll->getId())
                ->setIsDefaultBilling($addressId);
            $message = "Billing Address Updated Successfully";
        }else{
            $address->setCustomerId($customerscoll->getId())
                ->setIsDefaultShipping($addressId);
            $message = "Shipping Address Updated Successfully";
        }
        
        
        /*foreach ($customerscoll->getAddresses() as $address) {
            $country->loadByCode($address->getCountryId());      
            $street = $address->getstreet();      
            $allAddressData[] = array(
                "address_id" => $address->getEntityId(),
                "firstname" => $address->getfirstname(),
                "lastname" => $address->getlastname(),
                "city" => $address->getcity(),
                "region" => $address->getregion(),
                "postcode" => $address->getpostcode(),
                "telephone" => $address->gettelephone(),
                "street" => $street[0],
                "country" => $country->getName()
            );
        }*/
        if(!$address->getId()) {
            $response['status'] = 'fail';
            $response['data'] = '';
        }else{
            try{
                $address->save();
                $response['status'] = 'success';
                $response['message'] = $message;
                //$response['download_count'] = round($quote->getGrandTotal());            
                
            } catch (Exception $e) {
                $response['status'] = 'fail';
                $response['data'] = '';
            }
        }
        
        echo json_encode($response);exit;
        //echo "<pre>";print_r($allAddressData);exit;
    }
    public function addcartcustomAction(){
        $stoneHelper = Mage::helper('stone');
        $ringsizehelper = Mage::helper('qrcode');

        $Qty = $this->getRequest()->getParam('qty');
        $customerId = $this->getRequest()->getParam('customer_id');
        $productId = $this->getRequest()->getParam('product_id');

        $optionId = $this->getRequest()->getParam('option_id');
        $optiontypeId = $this->getRequest()->getParam('option_type_id');

        $stoneoptionId = $this->getRequest()->getParam('stone_option_id');
        $stoneoptiontypeId = $this->getRequest()->getParam('stone_option_type_id');

        $productId = $this->getRequest()->getParam('product_id');
        //$session = Mage::getSingleton('core/session', array('name' => 'frontend')); 
        $store = Mage::app()->getStore()->getStoreId();
        $productModel = Mage::getModel('catalog/product');
        $product1 = $productModel->load($productId)->setStoreId($store);
        
        $product  = Mage::getModel('catalog/product')->load($productId); 
        $parentIds = Mage::getResourceSingleton('catalog/product_type_configurable')
                  ->getParentIdsByChild($productId);
        $stone = $product->getRtsStoneQuality();
        $ringSize = $product->getRtsRingSize(); 
        
        if(isset($parentIds[0])){
            $parentconfigproduct = Mage::getModel('catalog/product')->load($parentIds[0]); //$pid     
            $productAttributeOptions = $parentconfigproduct->getTypeInstance(true)->getConfigurableAttributesAsArray($parentconfigproduct);
            $attributeOptions = array();
            $options = array();
            $attrCount = 0;
            foreach ($productAttributeOptions as $productAttribute) {
                $allValues = array_column($productAttribute['values'], 'value_index');
                $currentProductValue = $product->getData($productAttribute['attribute_code']);
                if (in_array($currentProductValue, $allValues)) {
                    if($product->getData('attribute_set_id') == 14){ //Rings
                        $options1[$productAttribute['attribute_id']] = $currentProductValue;
                        $options[$optionId] = $optiontypeId;
                        $options[$stoneoptionId] = $stoneoptiontypeId;
                    }else{
                        $options1[$productAttribute['attribute_id']] = $currentProductValue;
                        $options[$stoneoptionId] = $stoneoptiontypeId;
                    }
                }
            }
            
            $coll_options = Mage::getModel('catalog/product_option')->getProductOptionCollection($product);

            foreach ($coll_options as $option) {    
                
                if ($option->getType() === 'drop_down') {
                    $values = Mage::getSingleton('catalog/product_option_value')->getValuesCollection($option);
                    foreach ($values as $value) {
                        if($optiontypeId == $value['option_type_id'])
                        {
                            $RingTitle = $value['title'];
                        }
                    }                                     
                }
                if ($option->getType() === 'radio') {
                    $values = Mage::getSingleton('catalog/product_option_value')->getValuesCollection($option);
                    foreach ($values as $value) {
                        if($stoneoptiontypeId == $value['option_type_id'])
                        {
                            $StoneQualityTitle = $value['title'];
                        }
                    } 
                    
                }
            
            }

            // For Price change when options changes - start
            $updatedringweight =  $ringsizehelper->getMetalRingSize($productId,$RingTitle);
            $MetalDetails = $stoneHelper->getMetalData($productId);
            //echo "<pre>";print_r($gtotaldata);exit;
            $side_stone_data = $stoneHelper->getSideStoneData($productId, $StoneQualityTitle);
            $gem_stone_data = $stoneHelper->getGemStoneData($productId);
            $gtotaldata = $stoneHelper->getgrandtotal($MetalDetails['simple'],$side_stone_data['simple'],$gem_stone_data['simple'],$_blackdiamond = FALSE);
            $gtotalprice = $product->getCustomPrice();
            $finaltotal = str_replace('Rs.', '', $gtotaldata);
            $gtotalprice = str_replace(',', '', trim($finaltotal));

            // For Price change when options changes - end

            $paramater = array(
                'product' => $productId,
                'qty' => $Qty,
                'super_attribute' => $options1,
                'options' => $options,
                'cpid' => $parentconfigproduct->getId(),
                "form_key" => Mage::getSingleton('core/session')->getFormKey()
            );   
            //echo "<pre>";print_r($paramater);exit; 

                
        }else{
            $gtotalprice = $product->getCustomPrice();
            $coll_options = Mage::getModel('catalog/product_option')->getProductOptionCollection($product);
            foreach ($coll_options as $option) {    
                
                if ($option->getType() === 'drop_down') {
                    $values = Mage::getSingleton('catalog/product_option_value')->getValuesCollection($option)->getFirstItem();     
                    $optionId = $option['option_id'];
                    $optionsval = $values->getData('option_type_id');
                }
                if ($option->getType() === 'radio') {
                     $values = Mage::getSingleton('catalog/product_option_value')->getValuesCollection($option)->getFirstItem();
                    $stoneoption = $option['option_id'];
                    $stoneoptionval = $values->getData('option_type_id');
                }
            
            }
            $options = array($optionId => $optionsval,$stoneoption => $stoneoptionval);
            $paramater = array(
                'product' => $productId,
                'qty' => '1',
                'options' => $options,
                'customCalPrice' => $product->getCustomPrice(),
                "form_key" => Mage::getSingleton('core/session')->getFormKey()
            ); 
        }
         
        $productCollection = Mage::getModel('catalog/product')->load($productId);
        //echo "<pre>";print_r($product->getCustomPrice());exit; 
        //echo "<pre>";print_r($paramater);exit;
        
        $customer = Mage::getModel('customer/customer')->load($customerId);
        $quote = Mage::getModel('sales/quote')->loadByCustomer($customer);
        //$quote->setCheckoutMethod(Mage_Sales_Model_Quote::CHECKOUT_METHOD_LOGIN_IN);
        
        $quoteId = $quote->getId();
        $request = new Varien_Object($paramater);
        
        try{
            $request->setData($paramater);
            $quoteItem = $quote->addProduct($product, $request);
            $quote->setIsActive(1);
            //echo "<pre>";print_r($quote->getData());exit;
            foreach ($quote->getAllVisibleItems() as $item) {
                if($item->getProduct()->getId() != $productId) continue;
                $item->setCustomPrice(round($gtotalprice));
                $item->setOriginalCustomPrice(round($gtotalprice));
                $item->getProduct()->setIsSuperMode(true);      
            }
            $quote->setCheckoutMethod(Mage_Sales_Model_Quote::CHECKOUT_METHOD_LOGIN_IN);
            $quote->collectTotals()->save();

            Mage::getSingleton('checkout/session')->setCartWasUpdated(true);
            $rslt['status'] = 'success';
            $rslt['message'] = 'Product has been succefully added to cart';
        }catch(Exception $e){
            $rslt['status'] = 'fail';
            $rslt['message'] = $e->getMessage();
        }
        echo json_encode($rslt);exit;
               
    }

    public function listcartitemsAction(){
    $customerId = $this->getRequest()->getParam('customer_id');
    $customer = Mage::getModel('customer/customer')->load($customerId);
    $storeIds = Mage::app()->getWebsite(Mage::app()->getWebsite()->getId())->getStoreIds();
    $quote = Mage::getModel('sales/quote')->setSharedStoreIds($storeIds)->loadByCustomer($customer);

    $countqty = (int)$quote->getItemsQty();
    
    $productsResult = array();
    $metal_Quality = Mage::getModel("metal/metalquality");
    $ringsizehelper = Mage::helper('qrcode');
    $stoneHelper = Mage::helper('stone');
    if($countqty > 0){
        if ($quote) {
            foreach ($quote->getAllVisibleItems() as $item) {
            $product = $item->getProduct(); 
            $optionIds = $item->getOptionByCode('option_ids');
            $ProductImageCollection = Mage::getModel('catalog/product')->load($item->getProductId());
            $parentIds = Mage::getResourceSingleton('catalog/product_type_configurable')
                  ->getParentIdsByChild($item->getProductId());
            if(isset($parentIds[0])){
                $Type = "configurable";
            }else{
                $Type = "simple";
            }
            $price = $ProductImageCollection->getCustomPrice();
            $data = $metal_Quality->load($ProductImageCollection->getMetalQuality());
            $Metalinfo = $stoneHelper->getMetalData($item->getProductId());
            $coll_options = Mage::helper('catalog/product_configuration')->getCustomOptions($item);
            foreach ($coll_options as $option) { 
                if($ProductImageCollection->getData('attribute_set_id') == 14){
                    if ($option['option_type'] === 'drop_down') {
                        $ringsize = $option['value'];                    
                    }                    
                }else{
                    $ringsize = null;
                }
                if ($option['option_type'] === 'radio') {
                    $stonevalues = $option['value'];
                }
            }

            if($ProductImageCollection->getData('attribute_set_id') == 22){ //P&S
                $pendentAttr = $ProductImageCollection->getResource()->getAttribute('pendent_earring');
                $pendentSize = $pendentAttr->getSource()->getOptionText($ProductImageCollection->getPendentEarring());
            }elseif($ProductImageCollection->getData('attribute_set_id') == 18){ //pendent
                $optionstxt = "pendents";
            }elseif($ProductImageCollection->getData('attribute_set_id') == 17){ //bangles
                $bangleAttr = $ProductImageCollection->getResource()->getAttribute('bangle_size');
                $bangleSize = $bangleAttr->getSource()->getOptionText($ProductImageCollection->getBangleSize());
            }elseif($ProductImageCollection->getData('attribute_set_id') == 23){ //bracelets
                $braceletsAttr = $ProductImageCollection->getResource()->getAttribute('tennis_bangle_size');
                $braceletsSize = $braceletsAttr->getSource()->getOptionText($ProductImageCollection->getTennisBangleSize());
            }else{
                $optionstxt = "ringsize";
            }

            if($ProductImageCollection->getData('attribute_set_id') == 14){
                $updatedringweight =  $ringsizehelper->getMetalRingSize($item->getProductId(),$ringsize);
                $ringweight = number_format($updatedringweight, 2, '.', '');
                $metalDetails = $data->getData('metal_quality').'('.$ringweight.' gms)';
            }else{
                $weight = number_format($Metalinfo['weight'], 2, '.', '');
                $metalDetails = $data->getData('metal_quality').'('.$weight.' gms)';
            }
            $side_stone_data = $stoneHelper->getSideStoneData($item->getProductId(), $stonevalues);
            $stoneDetails = $stonevalues.'('.$side_stone_data['totalweight'][0].' ct)';

            // Product Image - start
            $url= Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_MEDIA);
            if($ProductImageCollection->getMetal() == 295 && empty($ProductImageCollection['media_gallery']['image'])){
                $urlIm = $url."catalog/product/y/e/yellow_".strtolower($ProductImageCollection->getOriginalSku()).'.jpg';
                if(!file_exists($urlIm))
                {
                    $yellowdeafultimg = Mage::helper('catalog/image')->init($ProductImageCollection, 'image');
                    $urlIm = $yellowdeafultimg->__toString();
                }
            }else if($ProductImageCollection->getMetal() == 294 && empty($ProductImageCollection['media_gallery']['image'])){
                $urlIm = $url."catalog/product/w/h/white_".strtolower($ProductImageCollection->getOriginalSku()).'.jpg';
                if(!file_exists($urlIm))
                {
                    $yellowdeafultimg = Mage::helper('catalog/image')->init($ProductImageCollection, 'image');
                    $urlIm = $yellowdeafultimg->__toString();
                }
            }else if($ProductImageCollection->getMetal() == 293 && empty($ProductImageCollection['media_gallery']['image'])){
                $urlIm = $url."catalog/product/product/r/o/rose_".strtolower($ProductImageCollection->getOriginalSku()).'.jpg';
                if(!file_exists($urlIm))
                {
                    $yellowdeafultimg = Mage::helper('catalog/image')->init($ProductImageCollection, 'image');
                    $urlIm = $yellowdeafultimg->__toString();
                }
            }else if($ProductImageCollection->getMetal() == 1393 && empty($ProductImageCollection['media_gallery']['image'])){
                $urlIm = $url."catalog/product/t/w/threetone_".strtolower($ProductImageCollection->getOriginalSku()).'.jpg';
                if(!file_exists($urlIm))
                {
                    $yellowdeafultimg = Mage::helper('catalog/image')->init($ProductImageCollection, 'image');
                    $urlIm = $yellowdeafultimg->__toString();
                }
            }else if($ProductImageCollection->getMetal() == 3118 && empty($ProductImageCollection['media_gallery']['image'])){
                $urlIm = $url."catalog/product/t/h/threetone_".strtolower($ProductImageCollection->getOriginalSku()).'.jpg';
                if(!file_exists($urlIm))
                {
                    $yellowdeafultimg = Mage::helper('catalog/image')->init($ProductImageCollection, 'image');
                    $urlIm = $yellowdeafultimg->__toString();
                }
            }else{
                $yellowdeafultimg = Mage::helper('catalog/image')->init($ProductImageCollection, 'image');
                $urlIm = $yellowdeafultimg->__toString();
            }
            // Product Image - end
            
            $count = Mage::helper('checkout/cart')->getSummaryCount();
            $subtotal = round($quote->getSubtotal());
            
            $gtotal = round($quote->getGrandTotal());
            Mage::getSingleton('checkout/session')->setCartWasUpdated(true);
            //echo "<pre>";print_r($quote->getData());exit;
            $taxAmount = $gtotal - $subtotal;
            $productsResult[] = array(
                    'product_type' => $Type,
                    'sku' => $product->getSku(),
                    'name' => $product->getName(),
                    'ringsize' => $ringsize,
                    'pendents' => $pendentSize,
                    'bangles' => $bangleSize,
                    'bracelets' => $braceletsSize,
                    'metaldetails' => $metalDetails,
                    'stonedetails' => $stoneDetails,
                    'price' => $price,
                    'itemid' => $item->getId(),
                    'qty' => $item->getQty(),
                    'image' => $urlIm
            );
            
        }  

    }
    
        try{
            $rslt['status'] = 'success';
            $rslt['data'] = $productsResult;
            $rslt['grandtotal'] = $gtotal;
            $rslt['subtotal'] = $subtotal;
            $rslt['tax'] = $taxAmount;
        }catch(Exception $e){
            $rslt['status'] = 'fail';
            $rslt['data'] = $e->getMessage();
        }
    }else{
        $message = "Cart is Empty";
        $rslt['status'] = 'fail';
        $rslt['message'] = $message;                
    }
        echo json_encode($rslt);exit;
    }

    public function removecartitemAction(){
        $id = $this->getRequest()->getParam('item_id');
        $customerId = $this->getRequest()->getParam('customer_id');
        $customer = Mage::getModel('customer/customer')->load($customerId);
        $storeIds = Mage::app()->getWebsite(Mage::app()->getWebsite()->getId())->getStoreIds();
        $quote = Mage::getModel('sales/quote')->setSharedStoreIds($storeIds)->loadByCustomer($customer);
        
        if ($id) {
            try {

                foreach ($quote->getAllVisibleItems() as $item) {
                    $_product = $item->getProduct();
                    if($id == $item->getId()) {
                        $quote->removeItem($item->getId())->save();
                    }                    
                }
                $quote->collectTotals()->save();
                Mage::getSingleton('checkout/session')->setCartWasUpdated(true);
                $message = 'Item was removed from your shopping cart.';
                $response['status'] = 'success';
                $response['message'] = $message;
            } catch (Exception $e) {
                $response['status'] = 'error';
                $response['message'] = 'Cannot remove the item from shopping cart.';
            }

            echo json_encode($response);exit;
        }
    }

    public function updatecartqtyAction(){
        $id = $this->getRequest()->getParam('item_id');
        $customerId = $this->getRequest()->getParam('customer_id');
        $qty = $this->getRequest()->getParam('qty');
        $customer = Mage::getModel('customer/customer')->load($customerId);
        $storeIds = Mage::app()->getWebsite(Mage::app()->getWebsite()->getId())->getStoreIds();
        $quote = Mage::getModel('sales/quote')->setSharedStoreIds($storeIds)->loadByCustomer($customer);
        $dataArr = array();
        $cart = Mage::getSingleton('checkout/cart');
        $cart->init();        
        //echo "<pre>";print_r($cart->getData());exit;
        if ($id) {
            try {
                foreach ($quote->getAllVisibleItems() as $item) {
                    $_product = $item->getProduct();
                    if($id == $item->getId()) {
                        $dataArr[$item->getId()]['qty'] = $item->getQty();
                        $cartData = $cart->suggestItemsQty($dataArr);
                        $cart->updateItems($cartData)->save();
                        $item->setQty($qty)->save();
                        
                    }   
                    $quote->collectTotals()->save();
                 Mage::getSingleton('checkout/session')->setCartWasUpdated(true);                   
                }
                
                //echo "<pre>";print_r($dataArr);exit;
                $message = 'Item was updated successfully.';
                $response['status'] = 'success';
                $response['message'] = $message;

            } catch (Exception $e) {
                $response['status'] = 'error';
                $response['message'] = 'Can not save item.';
            }
            echo json_encode($response);exit;
        }
    }

    // Payment Integration -start 
    public function paymentmethodsAction(){
        $customerId = $this->getRequest()->getParam('customer_id');
        $customer = Mage::getModel('customer/customer')->load($customerId);
        $storeIds = Mage::app()->getWebsite(Mage::app()->getWebsite()->getId())->getStoreIds();
        //$quote = Mage::getModel("checkout/cart")->getQuote();
        $quote = Mage::getModel('sales/quote')->setSharedStoreIds($storeIds)->loadByCustomer($customer);
        $BillingAdd = array(
            "address_id" => $quote->getBillingAddress()->getAddressId(),
            "firstname" => $customer->getDefaultBillingAddress()->getFirstname(),
            "lastname" => $customer->getDefaultBillingAddress()->getLastname(),
            "street" => $customer->getDefaultBillingAddress()->getStreet(),
            "country_id" => $customer->getDefaultBillingAddress()->getCountryId(),
            "region_id" => $customer->getDefaultBillingAddress()->getRegionId(), 
            "region" => $customer->getDefaultBillingAddress()->getRegion(),
            "city" => $customer->getDefaultBillingAddress()->getCity(),
            "postcode" => $customer->getDefaultBillingAddress()->getPostcode(),
            "telephone" => $customer->getDefaultBillingAddress()->getTelephone(),
            "company" => $customer->getDefaultBillingAddress()->getCompany(),
            "use_for_shipping" => 0
        );

        $ShippingAdd = array(
            "firstname" => $customer->getDefaultShippingAddress()->getFirstname(),
            "lastname" => $customer->getDefaultShippingAddress()->getLastname(),
            "street" => $customer->getDefaultShippingAddress()->getStreet(),
            "country_id " => $customer->getDefaultShippingAddress()->getCountryId(),
            "region_id" => $customer->getDefaultShippingAddress()->getRegionId(), 
            "region" => $customer->getDefaultShippingAddress()->getRegion(),
            "city" => $customer->getDefaultShippingAddress()->getCity(),
            "postcode" => $customer->getDefaultShippingAddress()->getPostcode(),
            "telephone" => $customer->getDefaultShippingAddress()->getTelephone(),
            "company" => $customer->getDefaultShippingAddress()->getCompany(),
        );

        $onepage = Mage::getSingleton('checkout/type_onepage');
        $billingresult = $onepage->saveBilling($BillingAdd, $customer->getDefaultBillingAddress()->getEntityId());
        $shippingresult = $onepage->saveShipping($ShippingAdd, $customer->getDefaultShippingAddress()->getEntityId());

        $quote->getShippingAddress()->collectTotals();
        $quote->getShippingAddress()->setCollectShippingRates(true);
        $quote->getShippingAddress()->collectShippingRates();
        $quote->setCheckoutMethod(Mage_Sales_Model_Quote::CHECKOUT_METHOD_LOGIN_IN);
        $getBillingAddress = $quote->getBillingAddress()->getFormated(true);
        
        $quote->collectTotals()->save();
        $quote->save();
        $rates = $quote->getShippingAddress()->getAllShippingRates();
        $AllShippingRates = $quote->getShippingAddress()->getGroupedAllShippingRates();
        $gtotal = round($quote->getGrandTotal());
        
        foreach ($rates as $key => $values) {
                $FinalShippingRates[] = array(
                    'rate_id' => $values->getRateId(),
                    'address_id' => $values->getAddressId(),
                    'carrier' => $values->getCarrier(),
                    'code' => $values->getCode(),
                    'method' => $values->getMethod(),
                    'price' => $values->getPrice(),
                    'method_title' => $values->getMethodTitle()
                );                                  
        }
        
        // For Remove Last Item from Array - start
        if (end($FinalShippingRates)) {
             array_pop($FinalShippingRates); 
        }

        //echo "<pre>";print_r($FinalShippingRates); exit;
        $Allmethods = $this->getAllMethods();
        try {
            foreach ($Allmethods as $key => $_methods) {
               $Methods[] = $_methods;
            }
            $response['status'] = 'success';
            $response['price'] = $gtotal;
            $response['shipping_charges'] = $FinalShippingRates;
            $response['data'] = $Methods;
        }catch (Exception $e) {
                $response['status'] = 'error';
                $response['data'] = '';
        }
        echo json_encode($response);exit;
    }

    public function getAllMethods(){
        $payments = Mage::getSingleton('payment/config')->getActiveMethods();
        $methods = array();

        foreach ($payments as $paymentCode=>$paymentModel) {
           
            if($paymentCode == 'ccavenuepay'){
                $image = "https://www.ccavenue.com/images_shoppingcart/ccavenue_logo_india.png";
            }
            $paymentTitle = Mage::getStoreConfig('payment/'.$paymentCode.'/title');
            $paymentaddd = Mage::getStoreConfig('payment/'.$paymentCode.'/mailing_address');
            if($paymentCode == 'paypal_billing_agreement' || $paymentCode == 'hdfc_debit' 
            || $paymentCode == 'hdfc_netbanking' || $paymentCode == '0'){continue;}
            $methods[$paymentCode] = array(
                'label'   => $paymentTitle,
                'value' => $paymentCode,
                'info' => $paymentaddd,
                'image' => $image
            );
           
        }
        return $methods;
    }
    // Payment Integration -end 


    public function paymentsaveAction(){

        $paymentmethod = $this->getRequest()->getParam('payment_method');
        $shippingmethod = $this->getRequest()->getParam('shipping_method');
        $shippingprice = $this->getRequest()->getParam('shipping_price');
        $customerId = $this->getRequest()->getParam('customer_id');
        $customer = Mage::getModel('customer/customer')->load($customerId);
        $storeIds = Mage::app()->getWebsite(Mage::app()->getWebsite()->getId())->getStoreIds();
        $quote = Mage::getModel('sales/quote')->setSharedStoreIds($storeIds)->loadByCustomer($customer);
        $shippingAddress = $quote->getShippingAddress();
        $shippingAddress->setShippingMethod($shippingmethod)->setPaymentMethod($paymentmethod);
        // Set payment method for the quote
        $quote->getPayment()->importData(array('method' => $paymentmethod));

        $shippingAddress->setShippingMethod($shippingmethod)->setCollectShippingRates(true);
        $shippingAddress->save();
        $quote->save();
        $quote->collectTotals()->save();
        try {
            $shippingAddress->save();
            $quote->save();
            $quote->collectTotals()->save();
            $message = 'Payment Method & Shipping Charges Added successfully.';
            $response['status'] = 'success';
            $response['message'] = $message;
            
        } catch (Mage_Core_Exception $e) {
            $message = 'There was an error processing your';
            $response['status'] = 'fail';
            $response['message'] = $message;
        }
        echo json_encode($response);exit;
        
    }


    public function orderdetailsviewAction(){
        //echo "<pre>";print_r(Mage::getSingleton('customer/session'));exit;
        $stoneHelper = Mage::helper('stone');
        $ringsizehelper = Mage::helper('qrcode');
        $customerId = $this->getRequest()->getParam('customer_id');
        $customer = Mage::getModel('customer/customer')->load($customerId);
        $storeIds = Mage::app()->getWebsite(Mage::app()->getWebsite()->getId())->getStoreIds();
        $quote = Mage::getModel('sales/quote')->setSharedStoreIds($storeIds)->loadByCustomer($customer);
        $quote->collectTotals()->save();

        $getBillingAddress = $quote->getBillingAddress()->getFormated(true);
        $getShippingAddress = $quote->getShippingAddress()->getFormated(true);
        
        $paymentcode = $quote->getPayment()->getMethodInstance()->getCode();
        $paymentTitle = Mage::getStoreConfig('payment/'.$paymentcode.'/title');
        
        $metal_Quality = Mage::getModel("metal/metalquality");

        foreach ($quote->getAllVisibleItems() as $item) {
            $ProductImageCollection = Mage::getModel('catalog/product')->load($item->getProductId());
            $price = $ProductImageCollection->getCustomPrice();
            $data = $metal_Quality->load($ProductImageCollection->getMetalQuality());
            $Metalinfo = $stoneHelper->getMetalData($item->getProductId());
            $coll_options = Mage::helper('catalog/product_configuration')->getCustomOptions($item);

            $data = $metal_Quality->load($ProductImageCollection->getMetalQuality());            

            foreach ($coll_options as $option) { 
                if($ProductImageCollection->getData('attribute_set_id') == 14){
                    if ($option['option_type'] === 'drop_down') {
                        $ringsize = $option['value'];                    
                    }                    
                }else{
                    $ringsize = null;
                }
                if ($option['option_type'] === 'radio') {
                    $stonevalues = $option['value'];
                }
            }
            if($ProductImageCollection->getData('attribute_set_id') == 14){
                $updatedringweight =  $ringsizehelper->getMetalRingSize($item->getProductId(),$ringsize);
                $ringweight = number_format($updatedringweight, 2, '.', '');
                $metalDetails = $data->getData('metal_quality').'('.$ringweight.' gms)';
            }else{
                $weight = number_format($Metalinfo['weight'], 2, '.', '');
                $metalDetails = $data->getData('metal_quality').'('.$weight.' gms)';
            }


            $side_stone_data = $stoneHelper->getSideStoneData($item->getProductId(), $stonevalues);
            $stoneDetails = $stonevalues.'('.$side_stone_data['totalweight'][0].' ct)';
            if($ProductImageCollection->getData('attribute_set_id') == 22){ //P&S
                $pendentAttr = $ProductImageCollection->getResource()->getAttribute('pendent_earring');
                $pendentSize = $pendentAttr->getSource()->getOptionText($ProductImageCollection->getPendentEarring());
            }elseif($ProductImageCollection->getData('attribute_set_id') == 18){ //pendent
                $optionstxt = "pendents";
            }elseif($ProductImageCollection->getData('attribute_set_id') == 17){ //bangles
                $bangleAttr = $ProductImageCollection->getResource()->getAttribute('bangle_size');
                $bangleSize = $bangleAttr->getSource()->getOptionText($ProductImageCollection->getBangleSize());
            }elseif($ProductImageCollection->getData('attribute_set_id') == 23){ //bracelets
                $braceletsAttr = $ProductImageCollection->getResource()->getAttribute('tennis_bangle_size');
                $braceletsSize = $braceletsAttr->getSource()->getOptionText($ProductImageCollection->getTennisBangleSize());
            }else{
                $optionstxt = "ringsize";
            }

           $shippingamt = $quote->getShippingAddress()->getShippingAmount();
           //echo "<pre>";print_r($quote->getGrandTotal());
           $orderDetails[] = array(
            "name" => $item->getName(),
            'sku' => $item->getSku(),
            "metaldetails" => $data->getData('metal_quality'),
            "stonequality" => $stonevalues,
            'ringsize' => $ringsize,
            'pendents' => $pendentSize,
            'bangles' => $bangleSize,
            'bracelets' => $braceletsSize,
            'qty' => $item->getQty(),
            'price' => (int)$item->getprice(),
            "subtotal" => $quote->getSubtotal()
            
            //"billing_address" => $getBillingAddress,
            //"shipping_address" => $getShippingAddress
           );
        }
            try {
                $response['status'] = 'success';
                $response['subtotal'] = round($quote->getSubtotal());
                $response['grand_total'] = round($quote->getGrandTotal());
                $response['tax_ammount'] = (int)$quote->getShippingAddress()->getTaxAmount();
                $response['payment'] = $paymentTitle;
                $response['shipping_charges'] = (int)$shippingamt;
                $response['data'] = $orderDetails;
            
            } catch (Exception $e) {
                $message = 'OrderDetails is Empty';
                $response['status'] = 'fail';
                $response['message'] = $message;
            }
        echo json_encode($response);exit;
        //exit;

        //echo $quotes->getBillingAddress();exit;

    }

    public function getcountCartandDownloadAction(){
        $accountdetailHelper = Mage::helper('accountdetail');
        $customerId = $this->getRequest()->getParam('customer_id');
        $Downalodcount = $accountdetailHelper->getCountDownloadProduct($customerId);
        $customer = Mage::getModel('customer/customer')->load($customerId);
        $storeIds = Mage::app()->getWebsite(Mage::app()->getWebsite()->getId())->getStoreIds();
        $quote = Mage::getModel('sales/quote')->setSharedStoreIds($storeIds)->loadByCustomer($customer);
        $totalQtyCount = $quote->getItemsCount();
        //echo "<pre>";print_r($Downalodcount);exit;
        try 
        {
            $response['status'] = 'success';
            $response['total_qty'] = (int)$totalQtyCount;
            $response['download_count'] = (int)$Downalodcount;            
            
        } catch (Exception $e) {
            $response['status'] = 'fail';
            $response['total_qty'] = '';
            $response['download_count'] = '';
            $response['download_count'] = '';
        }
        echo json_encode($response);exit;
    }



    public function createordersAction(){
        $dmlapiHelper = Mage::helper('dmlapi');
        $customerId = $this->getRequest()->getParam('customer_id');
        $customer = Mage::getModel('customer/customer')->load($customerId);
        $storeIds = Mage::app()->getWebsite(Mage::app()->getWebsite()->getId())->getStoreIds();
        $quote = Mage::getModel('sales/quote')->setSharedStoreIds($storeIds)->loadByCustomer($customer);
        $Billingdata = $customer->getDefaultBillingAddress()->getData();
        $Shippingdata= $customer->getDefaultShippingAddress()->getData();

        $quote->getShippingAddress()->setCustomerAddressId($customer->getDefaultBillingAddress()->getEntityId());
        $quote->getShippingAddress()->addData($Shippingdata);
        $quote->getBillingAddress()->addData($Billingdata);
        $quote->collectTotals()->save();  
        $quote->setSendCconfirmation(1);
        $quote->setIsActive(1);
        $quote->collectTotals()->save();  
        //echo "<pre>";print_r($quote->getBillingAddress()->getData()); exit;
        try{
            
            $service = Mage::getModel('sales/service_quote', $quote);
            $service->submitAll();
            $order =$service->getOrder(); 
            $payment_method_code = $order->getPayment()->getMethodInstance()->getCode();
            $order_id =  $order->getId();
            $Order_IncrementID = $order->getLastRealOrderId();
            $heplerfunc =  $dmlapiHelper->updateIsfranchiseeCustom($order_id,$customerId);
            $invoice = Mage::getModel('sales/service_order', $order)->prepareInvoice();
            $invoice->setRequestedCaptureCase(Mage_Sales_Model_Order_Invoice::CAPTURE_ONLINE);
            $invoice->register();
            $transactionSave = Mage::getModel('core/resource_transaction')
                ->addObject($invoice)
                ->addObject($invoice->getOrder());
            $transactionSave->save();
            //echo "<pre>";print_r($invoice->getData()); exit;
            if($payment_method_code == 'checkmo'){
                $message = 'Order Place successfully.';
                $response['status'] = 'success';
                $response['message'] = $message;

                $quoteItemCollection = Mage::getModel('sales/quote_item')->getCollection()->addFieldToFilter('quote_id', $quote->getId());

                $quoteItemArr = $quoteItemCollection->getData();

                foreach ($quoteItemArr as $quoteitem) {
                    $itemId = $quoteitem['item_id'];
                    $resource = Mage::getSingleton('core/resource');
                    $write = $resource->getConnection('core_write');
                    $quoteitemTable = $resource->getTableName('sales/quote_item');
                    $quote->removeItem($itemId)->setIsActive(1)->setItemsCount(0)->setItemsQty(0)->setGrandTotal(0.0000)->setBaseGrandTotal(0.0000)->setSubtotal(0.0000)->setBaseSubTotal(0.0000)->setSubtotalWithDiscount(0.0000)->setBaseSubtotalWithDiscount(0.0000)->setCheckoutMethod(null)->save();


                }
                
            }else{
                
            }
            
            
        }catch (Mage_Core_Exception $e) {
            echo $e;exit;
        }catch (Mage_Core_Exception $e) {
            echo $e->getMessage();exit;
        }
        echo json_encode($response);exit;
        //echo "<pre>";print_r($redirectUrl);exit;

    }
  
    /*public function getRSAkey($orderId){
        
        Mage::getUrl('dmlapi/addtocart/rsakey', array('order_id'=>$orderId));
    }*/

    public function getRSAkeyAction(){
        $accesscode = $this->getRequest()->getParam('access_code');
        $orderId = $this->getRequest()->getParam('order_id');
        $amount = "1000.00";
        $responseURL = $base_url.'ccavMobileResponseHandler.php';
        $url = "https://secure.ccavenue.com/transaction/getRSAKey";
        $fields = array(
            'access_code'=>$accesscode,
            'order_id'=>$orderId,
        );

        $postvars = '';
        $sep = '';
        foreach($fields as $key => $value)
        {
            $postvars .= $sep.urlencode($key).'='.urlencode($value);
            $sep = '&';
        }
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,$url);
        curl_setopt($ch, CURLOPT_POST,count($fields));
        curl_setopt($ch, CURLOPT_CAINFO, 'Crypto/cacert.pem');
        curl_setopt($ch, CURLOPT_POSTFIELDS,$postvars);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $key = curl_exec($ch);
        echo $key;exit;
        //echo "<pre>";print_r($key);exit;

    }

}