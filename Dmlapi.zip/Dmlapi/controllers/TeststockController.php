<?php
class Grp_Dmlapi_TeststockController extends Mage_Core_Controller_Front_Action {

	public function MystockViewAction() {

		$_allproductdparams = Mage::app()->getRequest()->getParams();

		$pagesize = $this->getRequest()->getParam('pagesize');
		$customerId = $this->getRequest()->getParam('customer_id');
		$customerData = Mage::getModel('customer/customer')->load($customerId);
		$group_id = Mage::app()->getRequest()->getParam('group_id');
		$group = Mage::getModel('customer/group')->load($group_id);
		$grouprole = $group->getData('customer_group_code');

		$category_arr = array();
		$category_arr['14'] = '14';
		$category_arr['6'] = '16';
		$category_arr['287'] = '22';
		$category_arr['7'] = '18';
		$category_arr['9'] = '17';
		$category_arr['124'] = '23';
		$category_arr['291'] = '32';

		// FOR FILTERS PARAMS

		if (!empty($_allproductdparams['price'])) {
			$price = explode('-', $_allproductdparams['price']);
		}

		if (!empty($_allproductdparams['category_id'])) {
			$categoryId = $_allproductdparams['category_id'];
		}

		if (isset($_allproductdparams['gold_purity']) && !empty($_allproductdparams['gold_purity'])) {
			$gold_purity = $_allproductdparams['gold_purity'];
		}

		$diamond_shape = isset($_allproductdparams['diamond_shape']) ? $_allproductdparams['diamond_shape'] : '';
		$diamonod_quality = isset($_allproductdparams['diamond_quality']) ? $_allproductdparams['diamond_quality'] : '';
		$sku = isset($_allproductdparams['sku']) ? $_allproductdparams['sku'] : '';

		// FOR FILTERS PARAMS

		if ($grouprole == 'Referral') {
			$ReferralId = $customerData->getData('parent_franchise_id');
			$productslist = Mage::getModel('franchises/franchisesorder')->getCollection()->addFieldToFilter('franchises_id', $ReferralId)->setOrder('franchises_order_id', 'DESC');
			$productslist->getSelect()->where('(main_table.type = 0 ) OR (main_table.type = 2 AND main_table.status = 3) OR (main_table.type = 1 AND main_table.status = 3)');
			$productslist->setPageSize(2)->setCurPage($pagesize);
		} else {
			$productslist = Mage::getModel('franchises/franchisesorder')->getCollection()->addFieldToFilter('franchises_id', $customerId)->setOrder('franchises_order_id', 'DESC');
			$productslist->getSelect()->where('(main_table.type = 0 ) OR (main_table.type = 2 AND main_table.status = 3) OR (main_table.type = 1 AND main_table.status = 3)');
			$is_sold = new Zend_Db_Expr("SELECT `entity_id`  FROM `catalog_product_flat_1` where  is_sold = 1");
			$productslist->addFieldToFilter('main_table.product_id', array('in' => $is_sold));

			$catalogQuery = new Zend_Db_Expr("(SELECT * FROM `catalog_product_flat_1` as cata)");

			$productslist->getSelect()
				->joinLeft(
					$catalogQuery,
					'main_table.certificate_no = t.certificate_no'
				);

			$productslist->setPageSize(2)->setCurPage($pagesize);
		}

		$productslist = $this->mystockfilter($customerId, $group_id, $price, $categoryId, $gold_purity, $diamonod_quality, $diamond_shape, $sku, null, null, $productslist, $category_arr);

		$data = array();
		if (($productslist->getSize() + 2) > ($pagesize * 2)) {
			foreach ($productslist as $_product) {
				$prdId = $_product->getProductId();
				$_product = Mage::getModel('catalog/product')->load($prdId);
				$_imgSize = '300';
				$img = Mage::helper('catalog/image')->init($_product, 'small_image')->keepFrame(false)->resize($_imgSize);
				if (strpos($img, "def_2")) {
					$urlIm = $img->__toString();
				} else {
					$urlIm = $img;
				}
				$image = $urlIm;
				$sku = $_product->getOriginalSku();

				/*Price - Start*/
				$pricefinal = Mage::helper('franchises')->getstoneprice($_product->getId());
				$referralDiscPriceFinal = Mage::helper('franchiseref')->getReferralProductPriceForMystock($_product);
				$totalprice = $pricefinal['price'];
				$price = $totalprice;
				if (isset($referralDiscPriceFinal) && $referralDiscPriceFinal['discPercent'] != 0) {
					$price = $referralDiscPriceFinal['price'];
					$referral_discount = $referralDiscPriceFinal['discPercent'] . '%';
				}

				/*Metal Quality - Start*/
				$attribute = Mage::getModel('eav/config')->getAttribute('catalog_product', 'metal_quality');
				$options = $attribute->getSource()->getAllOptions();
				$metal_quality = '';
				foreach ($options as $key => $value) {
					if ($value['value'] == $_product->getMetalQuality()) {
						$metal_quality = $value['label'];
					}
				}

				if (!empty($metal_quality)) {
					$words = explode(" ", $metal_quality);
					$acronym = "";

					foreach ($words as $wk => $w) {
						//var_dump($w);
						if ($wk != 0) {
							$acronym .= $w[0];
						} else {
							$acronym .= $w . ' ';
						}
					}
					$metal_quality = $acronym;
				}
				/*  Size - start */
				if ($_product->getRtsRingSize() != "") {
					$ringsize = $_product->getRtsRingSize();
					$attrname = "Ring";
					$size = $ringsize;
				} else if ($_product->getRtsBangleSize() != "") {
					$banglesize = $_product->getRtsBangleSize();
					$attrname = "Bangle";
					$size = $banglesize;
				} else if ($_product->getRtsBraceletSize() != "") {
					$braceletsize = $_product->getRtsBraceletSize();
					$attrname = "Bracelet";
					$size = $braceletsize;
				} else {
					$size = "";
				}

				$stone_quality = $_product->getRtsStoneQuality();
				$data[] = array('image' => $image, 'sku' => $sku, 'price' => $price, 'metal_quality' => $metal_quality, 'stone_quality' => $stone_quality, 'size' => $size);
			}
			echo json_encode(array('status' => 'success', 'customer_id' => $customerId, 'data' => $data));exit;
		} else {
			echo json_encode(array('status' => 'failure', 'customer_id' => $customerId, 'data' => $data));exit;
		}

	}

	public function mystockfilter($customerId = null, $groupId = null, $price = null, $category = null, $gold_purity = null, $diamonod_quality = null, $diamond_shape = null, $sku = null, $availability = null, $attributeSetId = null, $productCollection, $category_arr) {

		//var_dump($category);exit;
		//echo $productCollection->getSelect();exit;
		$price_start = '';
		$price_to = '';
		if (!empty($price)) {
			$price_start = $price[0];
			$price_to = $price[1];
		}
		if (!empty($price_start) && !empty($price_to)) {
			if ($price_start <= $price_to) {
				$productCollection->addFieldToFilter('custom_price', array('gteq' => $price_start))
					->addFieldToFilter('custom_price', array("lteq" => $price_to));
			}
		}
		if (!empty($sku)) {
			$productCollection->addFieldToFilter(
				array('t.sku', 't.certificate_no'),
				array(
					array('like' => '%' . $sku . '%'),
					array('like' => '%' . $sku . '%'),
				)
			);
		}
		if (!empty($diamonod_quality)) {
			$diamonod_quality = explode(',', $diamonod_quality);
			$productCollection->addFieldToFilter('rts_stone_quality', array('in' => $diamonod_quality));
		}
		if (!empty($gold_purity)) {
			$gold_purity = explode(',', $gold_purity);
			$productCollection->addFieldToFilter('metal_quality', array('in' => $gold_purity));
		}
		if (!empty($category)) {
			$productCollection->addFieldToFilter('attribute_set_id', $category_arr[$category]);
		}

		if (!empty($diamond_shape)) {
			$productCollection->getSelect()->joinRight(array('grp_stone' => 'grp_stone'), "t.entity_id = grp_stone.stone_product_id", array('stone_product_id'))
				->where("grp_stone.stone_shape in ($diamond_shape) ");
		}

		//echo $productCollection->getSelect();exit;
		/*if (!empty($availability)) {
				$productCollection->addAttributeToFilter("availability", $availability);
			}

			if (!empty($sort_by) && ($sort_by == 'sort_by_high_to_low')) {
				$productCollection->getSelect()->order('custom_price DESC');
			}
			if (!empty($sort_by) && ($sort_by == 'sort_by_low_to_high')) {
				$productCollection->getSelect()->order('custom_price ASC');
		*/

		/*if (!empty($sort_by) && ($sort_by == 'sort_by_qty')) {
				$productCollection->getSelect()->joinRight(array('grp_stone' => 'grp_stone'), "e.entity_id = grp_stone.stone_product_id", array('stone_product_id'))
					->where("grp_stone.stone_shape in ($diamond_shape) ");
			}
			if (!empty($sort_by) && ($sort_by == 'sort_by_latest')) {
				$productCollection->getSelect()->order('created_at DESC');
		*/

		return $productCollection;
	}

	/**
	 * Initialize product instance from request data
	 *
	 * @return Mage_Catalog_Model_Product || false
	 */
	protected function _initProduct() {
		$productId = (int) $this->getRequest()->getParam('product');
		if ($productId) {
			$product = Mage::getModel('catalog/product')
				->setStoreId(Mage::app()->getStore()->getId())
				->load($productId);
			if ($product->getId()) {
				return $product;
			}
		}
		return false;
	}

	/**
	 * Retrieve shopping cart model object
	 *
	 * @return Mage_Checkout_Model_Cart
	 */
	protected function _getCart() {
		//return Mage::getSingleton('checkout/cart');
		//return Mage::getModel("checkout/cart");
		return Mage::getModel('sales/quote')->loadByCustomer($customer);
	}

	/**
	 * Get checkout session model instance
	 *
	 * @return Mage_Checkout_Model_Session
	 */
	protected function _getSession() {
		return Mage::getSingleton('checkout/session');
	}

	public function addmystockproductAction() {

		/*try {
				$cart = Mage::getSingleton('checkout/cart');
				$cart->init();
				$options = array('1489195' => '20339143');
				$product = Mage::getModel('catalog/product')->load('1257745');
				$paramater = array('product' => '1257745',
					'qty' => '1',
					'options' => $options,
				);
				$request = new Varien_Object();
				$request->setData($paramater);
				$cart->addProduct($product, $request);
				echo "gfglfkdmg";exit;
				$cart->save();
				exit;
			} catch (Mage_Core_Exception $e) {
				if ($this->_getSession()->getUseNotice(true)) {
					$this->_getSession()->addNotice(Mage::helper('core')->escapeHtml($e->getMessage()));
					echo json_encode(array('status' => 'failure', 'customer_id' => $customerId, 'data' => $e->getMessage()));exit;
				} else {
					$messages = array_unique(explode("\n", $e->getMessage()));
					foreach ($messages as $message) {
						$this->_getSession()->addError(Mage::helper('core')->escapeHtml($message));
					}
					echo json_encode(array('status' => 'failure', 'customer_id' => $customerId, 'data' => $e->getMessage()));exit;
				}
			} catch (Exception $e) {
				$this->_getSession()->addException($e, $this->__('Cannot add the item to shopping cart.'));
				Mage::logException($e);
				echo json_encode(array('status' => 'failure', 'customer_id' => $customerId, 'data' => $this->__('Cannot add the item to shopping cart.') . ' ' . $e->getMessage()));exit;
				//$this->_goBack();
		*/

		/*  Remove cart forcefully */
		Mage::getSingleton('checkout/session')->setQuoteId(null);
		$cartHelper = Mage::helper('checkout/cart');
		$items = $cartHelper->getCart()->getItems();
		foreach ($items as $item) {
			$itemId = $item->getItemId();
			$cartHelper->getCart()->removeItem($itemId)->save();
			$this->_getSession()->setCartWasUpdated(true);
		}

		/*  End remove cart */

		$cart = $this->_getCart();
		//var_dump($cart);exit;

		// 1258260
		$params = Mage::app()->getRequest()->getParams();
		$customerId = $params['customer_id'];
		$customerData = Mage::getModel('customer/customer')->load($customerId); //insert cust ID
		//var_dump($customerData->getGroupId());exit;

		try {
			if (isset($params['qty'])) {
				$filter = new Zend_Filter_LocalizedToNormalized(
					array('locale' => Mage::app()->getLocale()->getLocaleCode())
				);
				$params['qty'] = $filter->filter($params['qty']);
			}
			$product = $this->_initProduct();
			$related = $this->getRequest()->getParam('related_product');
			if (!$product) {
				echo json_encode(array('status' => 'failure', 'customer_id' => $customerId, 'data' => false));exit;
			}
			$prdData = Mage::getModel('catalog/product')->load($product->getId());
			$stone = $prdData->getRtsStoneQuality();
			$ringSize = $prdData->getRtsRingSize();
			$data = $pricefinal = Mage::helper('franchises')->getstoneprice($product->getId());

			if (!$params['customCalPrice']) {
				$updatedPrice = Mage::helper('franchiseref')->updateCartPriceForReferralDisc($data['price']);
				$params['customCalPrice'] = $updatedPrice;
			} else {
				if ($customerData->getGroupId() == 5) {
					$price = preg_replace('/[^0-9]/', '', $params['customCalPrice']);
					$updatedPrice = Mage::helper('franchiseref')->updateCartPriceForReferralDisc($price);
					$params['customCalPrice'] = $updatedPrice;

				}
			}

			if (!$params['options']) {
				//echo '<pre>';
				//print_r($prdData->getOptions());
				//exit;
				foreach ($prdData->getOptions() as $_option) {
					$values = $_option->getValues();
					foreach ($values as $v) {
						if ($v->getTitle() == $stone) {
							$option_id = $v->getData('option_id');
							$value_id = $v->getData('option_type_id');
							//$params['options'] = array($option_id => $value_id);
							$custom_params[$option_id] = $value_id;
						}
						if ($v->getTitle() == $ringSize) {
							$option_id = $v->getData('option_id');
							$value_id = $v->getData('option_type_id');
							$custom_params[$option_id] = $value_id;
						}
					}
					$params['options'] = $custom_params;
				}
			}

			//echo '<pre>';
			//print_r($product->getData());
			//$params['options']['158'] = '2880';
			$params['customCalPrice'] = $product->getCustomPrice();
			//print_r($params);
			//exit;
			$cart->setCheckoutMethod(Mage_Sales_Model_Quote::CHECKOUT_METHOD_LOGIN_IN);
			$request = new Varien_Object($params);
			$request->setData($params);
			$cart->addProduct($product, $request);
			echo '<pre>';
			print_r($cart->getData());exit;
			if (!empty($related)) {
				$cart->addProductsByIds(explode(',', $related));
			}

			$cart->save();
			$this->_getSession()->setCartWasUpdated(true);
			$response = $this->placeReadytoShipOrder($product->getId(), $customerId);

			$this->getResponse()->setBody(Mage::helper('core')->jsonEncode($response));
			return;

		} catch (Mage_Core_Exception $e) {
			if ($this->_getSession()->getUseNotice(true)) {
				$this->_getSession()->addNotice(Mage::helper('core')->escapeHtml($e->getMessage()));
				echo json_encode(array('status' => 'failure', 'customer_id' => $customerId, 'data' => $e->getMessage()));exit;
			} else {
				$messages = array_unique(explode("\n", $e->getMessage()));
				foreach ($messages as $message) {
					$this->_getSession()->addError(Mage::helper('core')->escapeHtml($message));
				}
				echo json_encode(array('status' => 'failure', 'customer_id' => $customerId, 'data' => $e->getMessage()));exit;
			}
		} catch (Exception $e) {
			$this->_getSession()->addException($e, $this->__('Cannot add the item to shopping cart.'));
			Mage::logException($e);
			echo json_encode(array('status' => 'failure', 'customer_id' => $customerId, 'data' => $this->__('Cannot add the item to shopping cart.')));exit;
			//$this->_goBack();
		}

	}

	public function placeReadytoShipOrder($productId, $customerId) {

		$cart = Mage::getModel('checkout/session')->getQuote();
		$itemData = $cart->getAllVisibleItems();

		echo '<pre>';
		print_r($cart->getAllVisibleItems());exit;

		foreach ($cart->getAllVisibleItems() as $item) {

			if ($productId == $item->getProductId()) {
				$productArr = $item->getProduct();
				$customerSession = Mage::getModel('customer/customer')->load($customerId); //insert cust ID
				//$customerSession = Mage::getSingleton('customer/session')->getCustomer();
				//$customerperantid = $customerSession->getParentFranchiseId();
				//var_dump($customerperantid);exit;
				//$customer = Mage::getModel('customer/customer')->load($customerSession->getId());
				$customer = Mage::getModel('customer/customer')->load($customerId); //insert cust ID
				//var_dump($customer->getInvoiceSetting());exit;
				$customerBillingAddress = $customer->getPrimaryBillingAddress()->getData();
				$customerShippingAddress = $customer->getPrimaryShippingAddress()->getData();
				$firstName = $customer->getFirstname();
				$lastName = $customer->getLastname();
				$email = $customer->getEmail();

				$store = 1;
				$website_id = 1;

				$shippingMethod = 'freeshipping_freeshipping';
				$paymentMethod = 'checkmo';
				$quote = Mage::getSingleton('checkout/session')->getQuote();
				$finalsubtotal = round($quote->getSubtotal(), 0);
				$orderfrom = 'mystockorder';
				Mage::register('order_From', $orderfrom);

				$quote->setStoreId($store);
				$quote->setIsfranchisee(0);
				$quote->setIsFranchise(0);

				$quote->setCurrency(Mage::app()->getStore()->getBaseCurrencyCode());
				$quote->assignCustomer($customer);
				$billingAddressData = $quote->getBillingAddress()->addData($customerBillingAddress);
				$shippingAddressData = $quote->getShippingAddress()->addData($customerShippingAddress);
				$shippingAddressData->setCollectShippingRates(true)->collectShippingRates();
				$shippingAddressData->setShippingMethod($shippingMethod)->setPaymentMethod($paymentMethod);
				$quote->getPayment()->importData(array('method' => $paymentMethod));

				try {

					$quote->collectTotals();
					$quote->save();
					// 10% discount not applied if user is franchise referral

					if ($customer->getGroupId() != 5) {
						$quote = $this->setDiscount($quote);
						$quote->setIsFranchise(0);
						/* For DML Invoice Order - Start*/

						//$customerSession->getInvoiceSetting() = 0; // STATIC

						//if ($customerSession->getInvoiceSetting() == 0) {
						if (1 == 1) {
							$prdData = Mage::getModel('catalog/product')->load($productId);
							$store = Mage::app()->getStore();
							$taxCalculation = Mage::getModel('tax/calculation');
							$request = $taxCalculation->getRateRequest(null, null, null, $store);
							$taxClassId = $prdData->getTaxClassId();
							$percent = $taxCalculation->getRate($request->setProductClassId($taxClassId));
							$subtotalforRef = $quote->getSubtotal();
							$taxforref = (($subtotalforRef * $percent) / 100);
							$gtotal = $subtotalforRef + $taxforref;
							$quote->setTaxAmount($taxforref);
							$quote->setGrandTotal($gtotal);
							$quote->setBaseGrandTotal($gtotal);
							foreach ($quote->getAllItems() as $item) {
								$item->setSubtotal(round($gtotal), 0);
								$item->setRowTotal(round($subtotalforRef), 0);
								$item->setBaseRowTotal(round($subtotalforRef), 0);
								$item->setDiscountAmount(0);
								$item->setGrandTotal($gtotal);
							}

						} else {

							/*$rule = Mage::getModel('salesrule/rule')->load($quote->getAppliedRuleIds());
								                            $slabDiscount =  $rule->getDiscountAmount();
							*/
							//echo "<pre>";print_r($Discount_amount);exit;
							$prdData = Mage::getModel('catalog/product')->load($productId);
							$store = Mage::app()->getStore();
							$subtotalforRef = $quote->getSubtotal();
							$taxCalculation = Mage::getModel('tax/calculation');
							$request = $taxCalculation->getRateRequest(null, null, null, $store);
							$taxClassId = $prdData->getTaxClassId();
							$percent = $taxCalculation->getRate($request->setProductClassId($taxClassId));
							if (!empty($customer->getDiscountLessTwentyfive()) && $subtotalforRef <= '25000') {
								$Discount_amount = $customer->getDiscountLessTwentyfive();
								$quote->setDiscountDescription("Commission" . ' ' . $Discount_amount . '%');

							} else if (!empty($customer->getDiscountTwentyfiveToLakhs()) && $subtotalforRef >= '25000' && $subtotalforRef <= '100000') {

								$Discount_amount = $customer->getDiscountTwentyfiveToLakhs();
								$quote->setDiscountDescription("Commission" . ' ' . $Discount_amount . '%');

							} else if (!empty($customer->getDiscountAboveLakhs())
								&& $subtotalforRef >= '100000') {

								$Discount_amount = $customer->getDiscountAboveLakhs();
								$quote->setDiscountDescription("Commission" . ' ' . $Discount_amount . '%');

							} else {
								$rule = Mage::getModel('salesrule/rule')->load($quote->getAppliedRuleIds());
								$slabDiscount = $rule->getDiscountAmount();
								$Discount_amount = $slabDiscount;
							}

							$finalDiscount = (($subtotalforRef * $Discount_amount) / 100);
							$finalsubtotal = $subtotalforRef - $finalDiscount;
							$taxforref = (($subtotalforRef * $percent) / 100);
							$gtotal = $finalsubtotal + $taxforref;
							$quote->setTaxAmount($taxforref);
							$quote->setSubtotal($finalsubtotal);
							$quote->setGrandTotal($gtotal);
							$quote->setBaseGrandTotal($gtotal);
							foreach ($quote->getAllItems() as $item) {
								$item->setSubtotal(round($finalsubtotal), 0);
								$item->setDiscountAmount($finalDiscount);
								$item->setRowTotal(round($finalsubtotal), 0);
								$item->setBaseRowTotal(round($finalsubtotal), 0);
								$item->setCustomPrice(round($finalsubtotal), 0);
								$item->setOriginalCustomPrice(round($finalsubtotal), 0);
								$item->setGrandTotal($gtotal);
							}
						}
						/* For DML Invoice Order - End*/
					} else {
						$quote = $this->setDiscountNullForReferral($quote, $productId);
					}

					$service = Mage::getModel('sales/service_quote', $quote);
					$service->submitAll();

					//Order Increment Id
					$order = $service->getOrder();
					$incrementId = $service->getOrder()->getRealOrderId();

					//Update product status to sold = 'yes'
					$updateProduct = Mage::getModel('catalog/product')->load($productId);
					Mage::app()->setCurrentStore(Mage_Core_Model_App::ADMIN_STORE_ID);
					$updateProduct->setIsSold(1)->save();

					/*Forcefully Change - start */
					$resource = Mage::getSingleton('core/resource');
					$writeConnection = $resource->getConnection('core_write');
					$productId = $productId;
					$query = "UPDATE catalog_product_flat_1 SET is_sold = 1 WHERE entity_id = " . (int) $productId;
					$writeConnection->query($query);
					/*Forcefully Change - end */

					//Update product status to sold = '1' in franchise order table
					$updateFranchiseOrderProduct = Mage::getModel('franchises/franchisesorder')->getCollection()->addFieldToFilter('product_id', $productId);
					$updateFranchiseOrderProductArr = $updateFranchiseOrderProduct->getData();
					$franchiseOrderId = $updateFranchiseOrderProductArr[0]['franchises_order_id'];
					$updateFranchiseOrderProductData = Mage::getModel('franchises/franchisesorder')->load($franchiseOrderId);
					$status = Mage::getModel('franchises/franchisesorder')->load($franchiseOrderId)->getStatus();
					//check status before sale
					Mage::log("check status before sale$status" . $status, null, "S1.log");
					Mage::log(" Grapes_Franchises_Helper_Data::FRANCHISEE_DEFAULT_STATUS" . $status, null, "S1.log");
					if ($status == Grapes_Franchises_Helper_Data::FRANCHISEE_DEFAULT_STATUS || $status == Grapes_Franchises_Helper_Data::FRANCHISEE_DECLINE_STATUS) {
						$updateFranchiseOrderProductData->setData('type', 3)->save();
					}

					// Create Invoice programatically
					$invoice = Mage::getModel('sales/service_order', $order)->prepareInvoice();
					$invoice->setRequestedCaptureCase(Mage_Sales_Model_Order_Invoice::CAPTURE_ONLINE);
					$invoice->register();
					$transactionSave = Mage::getModel('core/resource_transaction')
						->addObject($invoice)
						->addObject($invoice->getOrder());
					if ($customerSession->getInvoiceSetting() == 0 && $customer->getGroupId() == 6) {
						$gtotalwithtax = $invoice->getBaseSubtotalInclTax();
						$invoice->setGrandTotal($gtotalwithtax);
					} elseif ($customerSession->getInvoiceSetting() == 1 && $customer->getGroupId() == 6) {

						$subTotal = $invoice->getSubtotal();
						if (!empty($customer->getDiscountLessTwentyfive()) && $subTotal <= '25000') {

							$Discount_amount = $customer->getDiscountLessTwentyfive();
							$invoice->setDiscountDescription("Commission" . ' ' . $Discount_amount . '%');

						} else if (!empty($customer->getDiscountTwentyfiveToLakhs()) && $subTotal >= '25000' && $subTotal <= '100000') {

							$Discount_amount = $customer->getDiscountTwentyfiveToLakhs();
							$invoice->setDiscountDescription("Commission" . ' ' . $Discount_amount . '%');

						} else if (!empty($customer->getDiscountAboveLakhs()) && $subTotal >= '100000') {

							$Discount_amount = $customer->getDiscountAboveLakhs();
							$invoice->setDiscountDescription("Commission" . ' ' . $Discount_amount . '%');

						} else {
							$rule = Mage::getModel('salesrule/rule')->load($quote->getAppliedRuleIds());
							$slabDiscount = $rule->getDiscountAmount();
							$Discount_amount = $slabDiscount;
						}
						$finalDiscount = (($subTotal * $Discount_amount) / 100);
						$finalsubtotal = $subTotal - $finalDiscount;
						$taxcal = $invoice->getTaxAmount();
						$gtotal = $finalsubtotal + $taxcal;
						$invoice->setSubtotal($subTotal);
						$invoice->setGrandTotal($gtotal);
						//echo "<pre>";print_r($invoice->getData());exit;
					}

					//start save invoice
					echo Mage::helper('franchises')->saveCustomInvoiceIncreIdByCustomer($invoice);
					$transactionSave->save();
					//end save invoice

					// Change order status to complete programatically
					$orderObj = Mage::getModel('sales/order')->loadByIncrementId($incrementId);
					$orderObj->setData('state', "complete");
					$orderObj->setStatus("complete");
					$orderObj->setIsfranchisee(0);
					Mage::log("$orderObj" . $status, null, "S1.log");
					$orderObj->setIsFranchise(0);
					if ($customerSession->getInvoiceSetting() == 0) {
						$prdData = Mage::getModel('catalog/product')->load($productId);
						$store = Mage::app()->getStore();
						$taxCalculation = Mage::getModel('tax/calculation');
						$request = $taxCalculation->getRateRequest(null, null, null, $store);
						$taxClassId = $prdData->getTaxClassId();
						$percent = $taxCalculation->getRate($request->setProductClassId($taxClassId));
						$subtotalforRef = $quote->getSubtotal();
						$taxforref = (($subtotalforRef * $percent) / 100);
						$gtotal = $subtotalforRef + $taxforref;
						$orderObj->setGrandTotal($gtotal);
						$orderObj->setBaseGrandTotal($gtotal);
					} else {
						/*$rule = Mage::getModel('salesrule/rule')->load($quote->getAppliedRuleIds());
							                        $slabDiscount =  $rule->getDiscountAmount();
						*/

						$subtotalforRef = $quote->getSubtotal();
						$basSubtotal = $quote->getBaseSubtotal(); // For actual price
						$prdData = Mage::getModel('catalog/product')->load($productId);
						$store = Mage::app()->getStore();
						$taxCalculation = Mage::getModel('tax/calculation');
						$request = $taxCalculation->getRateRequest(null, null, null, $store);
						$taxClassId = $prdData->getTaxClassId();
						$percent = $taxCalculation->getRate($request->setProductClassId($taxClassId));
						if (!empty($customer->getDiscountLessTwentyfive()) && $orderObj->getSubtotal() <= '25000') {

							$Mainprice = $orderObj->getSubtotal();
							$Discount_amount = $customer->getDiscountLessTwentyfive();
							$orderObj->setDiscountDescription("Commission" . ' ' . $Discount_amount . '%');
							$finalDiscount = (($Mainprice * $Discount_amount) / 100);
							$orderObj->setSubtotal($Mainprice);
							$orderObj->setDiscountAmount($finalDiscount);

						} else if (!empty($customer->getDiscountTwentyfiveToLakhs()) && $orderObj->getSubtotal() >= '25000' && $orderObj->getSubtotal() <= '100000') {

							$Mainprice = $orderObj->getSubtotal();
							$Discount_amount = $customer->getDiscountTwentyfiveToLakhs();
							$orderObj->setDiscountDescription("Commission" . ' ' . $Discount_amount . '%');
							$orderObj->setSubtotal($Mainprice);
							$finalDiscount = (($Mainprice * $Discount_amount) / 100);
							$orderObj->setDiscountAmount($finalDiscount);

						} else if (!empty($customer->getDiscountAboveLakhs()) && $orderObj->getSubtotal() >= '100000') {
							$Mainprice = $orderObj->getSubtotal();
							$Discount_amount = $customer->getDiscountAboveLakhs();
							$orderObj->setDiscountDescription("Commission" . ' ' . $Discount_amount . '%');
							$finalDiscount = (($Mainprice * $Discount_amount) / 100);
							$orderObj->setSubtotal($Mainprice);
							$orderObj->setDiscountAmount($finalDiscount);
						} else {
							$rule = Mage::getModel('salesrule/rule')->load($quote->getAppliedRuleIds());
							$slabDiscount = $rule->getDiscountAmount();
							$Discount_amount = $slabDiscount;
							$orderObj->setSubtotal($subtotalforRef);
						}

						$finalDiscount = (($subtotalforRef * $Discount_amount) / 100);
						$finalsubtotal = $subtotalforRef - $finalDiscount;
						$taxforref = (($basSubtotal * $percent) / 100);
						$gtotal = $subtotalforRef + $taxforref;
						$orderObj->setGrandTotal($gtotal);
						$orderObj->setBaseGrandTotal($gtotal);

					}

					$history = $orderObj->addStatusHistoryComment('Order was set to complete by our automation tool.', false);
					$history->setIsCustomerNotified(false);

					$Comission = $customerSession->getData('referral_comission');
					$discountAmount = round(($finalsubtotal * $Comission) / 100, 0);
					$orderObj->setFranchisecommissionpercent($Comission);
					$orderObj->setFranchisecommissionamt($discountAmount);

					Mage::log($franchiseComission . ' = ' . $discountAmount, null, "S1.log");
					$orderObj->save();

					//start- For Invoice Setting
					if ($customerSession->getInvoiceSetting() == 0) {
						Mage::helper('accountdetail')->getOrderFromDmlInvoice($orderObj);
					} else {
						Mage::helper('accountdetail')->getOrderFromFranchiseeInvoice($orderObj);
					}
					// end - For Invoice Setting

					$groupId = Mage::getSingleton('customer/session')->getCustomerGroupId();
					$group = Mage::getModel('customer/group')->load($groupId);
					if ($group->getCode() == 'Referral') {
						$permRef = "isReferral";
					}

					$response['success'] = 1;
					$response['isReferral'] = $permRef;
					$response['itemId'] = $item->getItemId();
					$response['orderid'] = $order->getId();
					$response['message'] = 'Your order <a href="' . Mage::getUrl() . 'sales/order/view/order_id/' . $order->getId() . '" title="#' . $incrementId . '">#' . $incrementId . '</a> has been placed successfully.</a>';

				} catch (Mage_Core_Exception $e) {
					$response['success'] = 0;
					$response['itemId'] = $item->getItemId();
					$response['message'] = 'Error to place an order "' . $e->getMessage() . '"';
				}
				//return $response;
				echo json_encode($response);exit;
			}
		}
	}

	public function setDiscount($quote) {
		$quoteid = $quote->getId();
		$finalsubtotal = round($quote->getSubtotal(), 0);
		$customerSession = Mage::getSingleton('customer/session')->getCustomer();
		$Comission = $customerSession->getData('referral_comission');

		//$franchiseComission = Mage::getStoreConfig('general/franchises/franchisecomission', Mage::app()->getStore());
		$discountAmount = round(($finalsubtotal * $Comission) / 100, 0);
		$quote->setFranchisecommissionpercent($Comission);
		$quote->setFranchisecommissionamt($discountAmount);
		if ($quoteid) {
			if ($discountAmount > 0) {
				$total = $quote->getBaseSubtotal();
				$quote->setSubtotal(0);
				$quote->setBaseSubtotal(0);
				$quote->setSubtotalWithDiscount(0);
				$quote->setBaseSubtotalWithDiscount(0);
				$quote->setGrandTotal(0);
				$quote->setTaxAmount(0);
				$quote->setBaseSubtotal(0);
				$quote->setBaseGrandTotal(0);
				$canAddItems = $quote->isVirtual() ? ('billing') : ('shipping');
				foreach ($quote->getAllAddresses() as $address) {
					$address->setSubtotal(0);
					$address->setBaseSubtotal(0);
					$address->setGrandTotal(0);
					$address->setBaseGrandTotal(0);
					$address->setTaxAmount(0);
					$address->setBaseSubtotal(0);
					$address->collectTotals();
					$quote->setSubtotal((int) $quote->getSubtotal() + $address->getSubtotal());
					$quote->setBaseSubtotal((int) $quote->getBaseSubtotal() + $address->getBaseSubtotal());
					$quote->setSubtotalWithDiscount(
						(int) $quote->getSubtotalWithDiscount() + $address->getSubtotalWithDiscount()
					);
					$quote->setBaseSubtotalWithDiscount(
						(int) $quote->getBaseSubtotalWithDiscount() + $address->getBaseSubtotalWithDiscount()
					);
					$quote->setGrandTotal((int) $quote->getGrandTotal() + $address->getGrandTotal());
					$quote->setBaseGrandTotal((int) $quote->getBaseGrandTotal() + $address->getBaseGrandTotal());
					$quote->save();
					$subtotal = $quote->getBaseSubtotal() - $discountAmount;
					$changegrandtotal = $this->getGrandtotals($subtotal);
					$quote->setGrandTotal($quote->getBaseSubtotal() - $discountAmount)
						->setSubtotal((int) $quote->getBaseSubtotal() - $discountAmount)
						->setBaseGrandTotal((int) $quote->getBaseSubtotal() - $discountAmount)
						->setSubtotalWithDiscount((int) $quote->getBaseSubtotal() - $discountAmount)
						->setBaseSubtotalWithDiscount((int) $quote->getBaseSubtotal() - $discountAmount)
						->setTaxAmount($changegrandtotal['tax'])
						->setGrandTotal($changegrandtotal['grantotal']);
					$quote->save();

					if ($address->getAddressType() == $canAddItems) {
						$address->setSubtotal((int) $address->getSubtotalWithDiscount() - $discountAmount);
						$address->setSubtotalWithDiscount((int) $address->getSubtotalWithDiscount() - $discountAmount);
						$address->setGrandTotal((int) $address->getGrandTotal() - $discountAmount);
						$address->setBaseSubtotalWithDiscount((int) $address->getBaseSubtotalWithDiscount() - $discountAmount);
						$address->setBaseGrandTotal((int) $address->getBaseGrandTotal() - $discountAmount);
						$address->setTaxAmount($changegrandtotal['tax']);
						$address->setGrandTotal($changegrandtotal['grantotal']);
						if ($address->getDiscountDescription()) {
						} else {
						}
						$address->save();
					}
				}
				foreach ($quote->getAllVisibleItems() as $item) {
					Mage::log($item->getId(), null, "trace1.log");
					$newPrice = $quote->getSubtotal();
					$rowtotandbase = $newPrice * $quote->getItemsQty();
					if ($newPrice > 0) {
						$item->setCustomPrice(round($newPrice), 0);
						Mage::log($newPrice, null, "trace1.log");
						$item->setOriginalCustomPrice(round($newPrice), 0);
						$item->setRowTotal(round($rowtotandbase), 0);
						Mage::log($rowtotandbase, null, "trace1.log");
						$item->setBaseRowTotal(round($rowtotandbase), 0);
						$item->getProduct()->setIsSuperMode(true);
						$item->save();
					}
				}

				$quote->save();

			}
		}
		//echo "<pre>";print_r($quote->getData());echo "</pre>";exit;
		return $quote;
	}

}