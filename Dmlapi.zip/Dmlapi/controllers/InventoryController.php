<?php
class Grp_Dmlapi_InventoryController extends Mage_Core_Controller_Front_Action {
	
	//Generate invoice for dmlsoftware
    public function generateInvoiceAction()
    {
    	$params = Mage::app()->getRequest()->getParams();
    	$write = Mage::getSingleton("core/resource")->getConnection("core_write");
    	$productIds = isset($params['productIds']) ? $params['productIds'] : '';
    	$customerId = isset($params['customerId']) ? $params['customerId'] : '';
    	$productIds = isset($params['productIds']) ? $params['productIds'] : '';
    	$invoiceNumber = isset($params['invoice_number']) ? $params['invoice_number'] : '';
    	$invoiceDate = isset($params['invoice_date']) ? $params['invoice_date'] : '';

    	if (strpos($productIds, ',') !== false) {
		    $productIds = explode(',', $productIds);
		}
		else
		{
			$productIds = array($productIds);	
		}
    	$paymentData = json_decode($params['paymentData']);
    	//echo "<pre>";
    	//print_r($paymentData);exit;
    	$paymentMode = isset($paymentData->payment_mode) ? $paymentData->payment_mode : '';
    	$discountType = isset($paymentData->discount_type) ? $paymentData->discount_type : '';
    	$discountValue = isset($paymentData->discount_value) ? $paymentData->discount_value : '';
    	$franchiseId = isset($paymentData->franchise_id) ? $paymentData->franchise_id : '';
    	$franchiseName = isset($paymentData->franchise_name) ? $paymentData->franchise_name : '';
    	$franchiseCommision = isset($paymentData->franchise_commision) ? $paymentData->franchise_commision : '';
    	$agentName = isset($paymentData->agent_name) ? $paymentData->agent_name : '';
    	$agentCommission = isset($paymentData->agent_commision) ? $paymentData->agent_commision : '';
    	$store = Mage::app()->getStore();
    	$website = Mage::app()->getWebsite();
    	
    	$customer = Mage::getModel("customer/customer")->load($customerId);
    	$defaultBilling = $customer->getDefaultBilling();
    	$address = Mage::getModel("customer/address")->load($defaultBilling);
    	//print_r($customer->getPrimaryBillingAddress());exit;
    	$customerBillingAddress = $customer->getPrimaryBillingAddress()->getData();
    	$customerShippingAddress = $customer->getPrimaryShippingAddress()->getData();
    	$shippingMethod = 'freeshipping_freeshipping';
		$paymentMethod = 'checkmo';

		$quote = Mage::getModel('sales/quote')->setStoreId($store->getStoreId());
		$quote->assignCustomer($customer);
		$quote->setIsfranchisee(1);
		$quote->setIsFranchise(1);

		if(!empty($discountValue) && $discountType=='percent')
		{
			$quote->setCustomDiscountPercent($params['discount_value']);
		}
		else if(!empty($discountValue) && $discountType=='amount')
		{
			$quote->setCustomDiscountAmount($params['discount_value']);
		}
    	if(count($productIds) > 0)
    	{
    		$alreadyGeneratedInvoice = array();
    		foreach ($productIds as $key => $productId) {
    			/*$order = Mage::getResourceModel('sales/order_item_collection')->addAttributeToFilter('product_id', array('eq' => $productId))->load();
				$order->getSelect()->join(array('od' => 'sales_flat_order'), 'od.entity_id = main_table.order_id', array('status'))->where('od.status = "pending"');*/
				$products_collection = Mage::getModel('catalog/product')->getCollection()->addAttributeToFilter('entity_id', array('eq' => $productId))->addAttributeToSelect('certificate_no')->addAttributeToSelect('approval_invoice_generated');
				$productData = $products_collection->getData();
				//echo $products_collection->getSelect();exit;
				foreach ($productData as $key => $product) {
		        	if($product['approval_invoice_generated'])
		        	{
		        		$alreadyGeneratedInvoice[] = $product['certificate_no'];
		        	}
		        }
    		}

    		if(count($alreadyGeneratedInvoice) > 0)
			{
				//echo implode(",",$alreadyGeneratedMemo);exit;
				$message = 'Invoice already generated for Certificate(s): '.implode(", ",$alreadyGeneratedInvoice);
				$response['message'] = $message;
				$response['status'] = 0;
				echo json_encode($response);exit;
				//break;
			}
			foreach ($productIds as $key => $productId) {
				$order = Mage::getResourceModel('sales/order_item_collection')->addAttributeToFilter('product_id', array('eq' => $productId))->load();
				$order->getSelect()->join(array('od' => 'sales_flat_order'), 'od.entity_id = main_table.order_id', array('status'))->where('od.status = "pending"');
				if($order->getSize() < 1)
				{
					$this->IsupdateVirtualManager($productId);
					$collection = Mage::getResourceModel('sales/order_item_collection')->addAttributeToFilter('product_id', array('eq' => $productId))->load();
					$product = Mage::getModel('catalog/product')->load($productId);
					$product->setPrice($product->getCustomPrice());
					$product->setTaxClassId(2);
					$optionId = 0;
					$options = array();
					foreach ($product->getOptions() as $option) {
						$optionId = $option->getOptionId();
						$optionValue = $option->getValues();
						$options[$optionId] = $optionValue;
					}
					$buyInfo = array(
						'qty' => 1,
						'options' => $options,
					);
					$quote->addProduct($product, new Varien_Object($buyInfo));
					//print_r($quote->getData());exit;
				}
			}
			$billingAddressData = $quote->getBillingAddress()->addData($customerBillingAddress);
			$shippingAddressData = $quote->getShippingAddress()->addData($customerShippingAddress);
			$shippingAddressData->setCollectShippingRates(true)->collectShippingRates();

			$shippingAddressData->setShippingMethod($shippingMethod)->setPaymentMethod($paymentMethod);
			$quote->getPayment()->importData(array('method' => $paymentMethod));
			$TaxAmount = $quote->getShippingAddress()->getData('tax_amount');
    		if ($quote->getSubtotal() >= 200000 && $paymentMode == "Cash") {
				$message = "You can't generate Invoice with Cash on delivery Payment mode as Order amount exceeds 2 Lacs.";
				$response['status'] = 2;
				$response['message'] = $message;
				echo json_encode($response);exit;
			}
			// For DISCOUNT DIVIDED BY ITEM IN ADMIN - START
			if (!empty($discountValue) && $discountType=='percent') {
				$percentdisc = $discountValue;
				$finalamt = $quote->getSubtotal();
				$discountamt = ($finalamt * $percentdisc) / 100;
			} else if(!empty($discountValue) && $discountType=='amount'){
				$itemcount = $quote->getItemsCount();
				$discountamt = $discountValue / $itemcount;
			}
			// FOR DISCOUNT DIVIDED BY ITEM IN ADMIN - END
			$quote->collectTotals()->save();
			// For Set Final Total In Admin - Start 
			if (!empty($discountValue) && $discountType=='percent') {
				$gtotal = $quote->getSubtotal();
				$discountindividuals = ($gtotal * $quote->getCustomDiscountPercent() / 100);
				$discountindividual = $discountindividuals;
				$FinalGrandTotal = ($gtotal + $TaxAmount) - $discountindividual;
			} else {
				$gtotal = $quote->getSubtotal();
				$FinalGrandTotal = ($gtotal + $TaxAmount);
			}
			if (!empty($discountValue)) {
				$discountindividual = $quote->getCustomDiscountAmount();
				$gtotal = $quote->getSubtotal();
				$FinalGrandTotal = ($gtotal + $TaxAmount) - $discountindividual;
			} else {
				$gtotal = $quote->getSubtotal();
				$FinalGrandTotal = ($gtotal + $TaxAmount);
			}
			foreach ($quote->getAllAddresses() as $address) {
				$address->setDiscountAmount($discountindividual);
				$address->setBaseDiscountAmount($discountindividual);
				$address->setGrandTotal($FinalGrandTotal);
				$address->setBaseGrandTotal($FinalGrandTotal);
				$address->save();
			}
			//$orderCollection = Mage::getResourceModel('sales/order_item_collection');
			foreach ($productIds as $key => $productId) {
				$orderCollection = Mage::getResourceModel('sales/order_item_collection')->addAttributeToFilter('product_id', array('eq' => $productId))->load();
				$orderCollection->getSelect()->join(array('od' => 'sales_flat_order'), 'od.entity_id = main_table.order_id', array('status'))->where('od.status = "pending"');
				if($orderCollection->getSize() > 0)
				{
					foreach ($orderCollection as $key => $order) {
						$orderId = $order->getData('order_id');
					}
					$order = Mage::getModel('sales/order')->load($orderId);
					
					$orderIds[] = $orderId;
				}
				else
				{
					$service = Mage::getModel('sales/service_quote', $quote);
					$service->submitAll();
					$order = $service->getOrder();
					$lastOrder = Mage::getModel('sales/order')->getCollection()
						       ->setOrder('entity_id','DESC')
						       ->setPageSize(1)
						       ->getFirstItem();
			        $orderIds[] = $lastOrder->getEntityId();
				}
				$status = '';
				$statusLabel = '';
				$inventory_status = Mage::getModel('eav/config')->getAttribute('catalog_product','inventory_status');
				$inventory_status = Mage::getModel('eav/entity_attribute_source_table')->setAttribute($inventory_status)->getAllOptions(false);
							
				foreach($inventory_status as $inventory_status)
				{
						if(trim(strtolower($inventory_status['label'])) == 'sold out') 
						{
							$status = $inventory_status['value'];
							$statusLabel = $inventory_status['label'];
						}
				}
				$query = "UPDATE catalog_product_flat_1 SET `approval_invoice_generated` = '1',`inventory_status`='".$status."',inventory_status_value='".$statusLabel."' WHERE entity_id=".$productId;

				//	Mage::helper('virtualproductmanager')->getChangeproductstatus($productId, "sold out");
				$write->query($query);
			}
			$resource = Mage::getSingleton('core/resource');
			$writeConnection = $resource->getConnection('core_write');
			$readConnection = $resource->getConnection('core_read');
			$orderIds = array_unique($orderIds);
			foreach ($orderIds as $key => $orderId) {
				$order = Mage::getModel('sales/order')->load($orderId);
				if (!empty($discountValue) && $discountType=='percent') {
					$order->setCustomDiscountPercent($discountValue);
				}
				if(!empty($discountValue) && $discountType=='amount'){
					$order->setCustomDiscountAmount($discountValue);
				}
				foreach ($order->getAllItems() as $item) {
					$item->setDiscountAmount($discountamt);
					$item->setBaseDiscountAmount($discountamt);
					$productID = $item->getProductId();
					$Checkvalue = "Select * from `qrcode_inventory_management` where pr_id =" . $productID;
					$rs = $readConnection->fetchOne($Checkvalue);
					if (empty($rs)) {
						$query = "INSERT INTO `qrcode_inventory_management` (`pr_id`,`pr_sku`,`pr_name`,`inventory_status`,`soldout_date`,`release_date`) VALUES ('" . $productID . "', '" . $item->getSku() . "','" . $item->getName() . "','sold out','" . date('Y-m-d') . "','" . date('Y-m-d') . "')";
						$writeConnection->query($query);
					} else {
						$write = Mage::getSingleton("core/resource")->getConnection("core_write");
						$query = "UPDATE qrcode_inventory_management SET `pr_id` = '" . $productID . "', `pr_sku` = '" . $item->getSku() . "', `pr_name` = '" . $item->getName() . "', `inventory_status` = 'sold out', `soldout_date` = '" . date('Y-m-d') . "', `release_date` = '" . date('Y-m-d') . "' WHERE pr_id=" . $productID;
						$write->query($query);
					}
					$InventoryStatus = Mage::getStoreConfig('virtualproductmanager/qrinventorymngmt/currentmode');
					Mage::helper('virtualproductmanager')->getChangeproductstatus($productID, "sold out");
					if (!empty($productID)) {
						$this->deleteProductInvoice($productID);
					}
				}
				$incrementId = $order->getRealOrderId();
				$items = array();
				foreach ($order->getAllItems() as $item) {
				    $items[$item->getId()] = $item->getQtyOrdered();
				}
				$invoice = Mage::getModel('sales/service_order', $order)->prepareInvoice();
				if(!empty($invoiceNumber))
					$invoice->setIncrementId($invoiceNumber);
				if(!empty($invoiceDate))
					$invoice->setCreatedAt(date('Y-m-d h:i:s',strtotime($invoiceDate)));
				$invoice->setRequestedCaptureCase(Mage_Sales_Model_Order_Invoice::CAPTURE_ONLINE);
				$invoice = $invoice->register();
				$transactionSave = Mage::getModel('core/resource_transaction')->addObject($invoice)
						->addObject($invoice->getOrder());
				$transactionSave->save();
				$newFranchiseIncrId = str_replace(substr($incrementId, 0, 2), '11', $incrementId);
				$order = Mage::getModel('sales/order')->loadByIncrementId($incrementId);
				$order->setPaymentMode($paymentMode);
				$order->setFranchiseOrderIncrementId($newFranchiseIncrId);
				$order->setAgentName($agentName);
				$order->setSelectedFranchiseId($franchiseId);
				$order->setSelectedFranchiseCommission($franchiseCommision);
				$order->setAgentCommission($agentCommision);
				$order->setQrProductStatus(1);
				$order->setData('state', "complete");
				$order->setStatus("complete");
				/*INVOICE CODE END*/
				$query = "select approval_memo_number from sales_flat_invoice where approval_memo_number is not null order by entity_id desc limit 1";
			    $result = $readConnection->fetchCol($query);
			    $findquery = "select approval_memo_number from sales_flat_invoice where approval_memo_number is not null and approval_memo_number = '19-20/106' order by entity_id desc limit 1";
			    $findresult = $readConnection->fetchCol($findquery);
			    if((!empty($findresult[0]))){
			    	if(count($result) > 0){
				    	if((!empty($result[0])))
					    {					     
						        $memoNumber = $result[0];
						        $finalnumber = array_pop(explode('/', $memoNumber));
						        $memofinal = $finalnumber+1;
						        $returnNumber = str_replace('19-20/106','','19-20/'.$memofinal);
						}else{
				        	$returnNumber = "19-20/106";
				      	}
				    }else{
			        	$returnNumber = "19-20/106";
			      	}
			    }else{
			    	$returnNumber = "19-20/106";
			    }
			    $invoice->setApprovalMemoNumber($returnNumber);
				$invoice->save();	
				//$orderObj->setState(Mage_Sales_Model_Order::STATE_NEW, true);
				$order->save();   
				//exit;
			}
			$response['status'] = 1;
			$response['order_id'] = $incrementId;
			$response['message'] = 'Invoice Generated Successfully...';
			echo json_encode($response);exit;
    	}
    }
    public function deleteProductInvoice($productID) {
		if (!empty($productID)) {
			$write = Mage::getSingleton("core/resource")->getConnection("core_write");
			$query = "DELETE FROM grp_qradd_product WHERE pro_id=" . $productID;
			$write->query($query);
		}
	}
    public function IsupdateVirtualManager($productId)
	{
		$productCollection = Mage::getModel('catalog/product')->load($productId);
		$certificate = $productCollection->getData('certificate_no');
		$virtualProductManagerCollection = Mage::getModel('virtualproductmanager/productmanager')->getCollection();
		$virtual_certificate_expo = array();
		foreach ($virtualProductManagerCollection as $key => $virtualdataColl) {
			$virtual_certificates =  $virtualdataColl->getData('product_manager_certificates');
			$virtual_certificate_expo[$key] = explode(",",$virtual_certificates);
		}
		$certies = array();

		foreach ($virtual_certificate_expo as $virtual_certificate_expokey=>$virtual_certificate_expovalue) 
		{
			if(in_array($certificate,$virtual_certificate_expovalue)) {

				$key_of_exist = array_search($certificate, $virtual_certificate_expovalue);
				unset($virtual_certificate_expovalue[$key_of_exist]);
				$product_certificate_forsave = implode(',', $virtual_certificate_expovalue);
				$data = array('product_manager_id'=>$virtual_certificate_expokey,'product_manager_certificates'=>$product_certificate_forsave);
				$vir_coll = Mage::getModel('virtualproductmanager/productmanager')->setData($data)->save();
			}
		}
	}
	//Generate memo
	public function generateMemoAction()
	{
		$params = Mage::app()->getRequest()->getParams();
    	$write = Mage::getSingleton("core/resource")->getConnection("core_write");
    	$productIds = isset($params['productIds']) ? $params['productIds'] : '';
    	
    	if (strpos($productIds, ',') !== false) {
		    $productIds = explode(',', $productIds);
		}
		else
		{
			$productIds = array($productIds);	
		}
    	$customerId = isset($params['customerId']) ? $params['customerId'] : '';
    	
    	$paymentData = json_decode($params['paymentData']);
    	$approvalNumber = isset($params['approval_number']) ? $params['approval_number'] : '';
    	$approvalDate = isset($params['approval_date']) ? $params['approval_date'] : '';

    	$approvalType = isset($paymentData->approval_type) ? $paymentData->approval_type : ''; 
    	$paymentMode = isset($paymentData->payment_mode) ? $paymentData->payment_mode : '';
    	$discountType = isset($paymentData->discount_type) ? $paymentData->discount_type : '';
    	$discountValue = isset($paymentData->discount_value) ? $paymentData->discount_value : '';
    	$franchiseId = isset($paymentData->franchise_id) ? $paymentData->franchise_id : '';

    	$franchiseName = isset($paymentData->franchise_name) ? $paymentData->franchise_name : '';
    	$franchiseCommision = isset($paymentData->franchise_commision) ? $paymentData->franchise_commision : '';
    	$agentName = isset($paymentData->agent_name) ? $paymentData->agent_name : '';
    	$agentCommission = isset($paymentData->agent_commision) ? $paymentData->agent_commision : '';
    	$store = Mage::app()->getStore();
    	$website = Mage::app()->getWebsite();

    	$customer = Mage::getModel("customer/customer")->load($customerId);
    	$defaultBilling = $customer->getDefaultBilling();
    	$address = Mage::getModel("customer/address")->load($defaultBilling);
    	//print_r($customer->getPrimaryBillingAddress());exit;
    	$customerBillingAddress = $customer->getPrimaryBillingAddress()->getData();
    	$customerShippingAddress = $customer->getPrimaryShippingAddress()->getData();
    	$shippingMethod = 'freeshipping_freeshipping';
		$paymentMethod = 'checkmo';
		$quote = Mage::getModel('sales/quote')->setStoreId($store->getStoreId());
		$quote->setIsfranchisee(1);
		$quote->setIsFranchise(1);
		if(!empty($discountValue) && $discountType=='percent')
		{
			$quote->setCustomDiscountPercent($params['discount_value']);
		}
		else if(!empty($discountValue) && $discountType=='amount')
		{
			$quote->setCustomDiscountAmount($params['discount_value']);
		}
		$quote->setPaymentMode($paymentMethod);

		$quote->setSelectedFranchiseId($franchiseId);
		$quote->setSelectedFranchiseCommission($franchiseCommision);
		$quote->setAgentName($agentName);
		$quote->setAgentCommission($agentCommission);
		$quote->setQrProductStatus(1);
		$quote->assignCustomer($customer);
		$quote->setSendConfirmation(1);

		if(count($productIds) > 0)
		{
			$alreadyGeneratedMemo = array();
			foreach ($productIds as $key => $productId) {
				$order = Mage::getResourceModel('sales/order_item_collection')->addAttributeToFilter('product_id', array('eq' => $productId))->load();
				$order->getSelect()->join(array('od' => 'sales_flat_order'), 'od.entity_id = main_table.order_id', array('status'))->where('od.status = "pending"');
				//echo $order->getSelect();exit;
				if ($order->getSize() > 0) {
					$products_collection = Mage::getModel('catalog/product')->getCollection()->addAttributeToFilter('entity_id', array('eq' => $productId))->addAttributeToSelect('certificate_no')->addAttributeToSelect('approval_memo_generated');
					$productData = $products_collection->getData();
					foreach ($productData as $key => $product) {
			        	$alreadyGeneratedMemo[] = $product['certificate_no'];
			        }
				}
			}
			if(count($alreadyGeneratedMemo) > 0)
			{
				//echo implode(",",$alreadyGeneratedMemo);exit;
				$message = 'Memo already generated for Certificate(s): '.implode(", ",$alreadyGeneratedMemo);
				$response['message'] = $message;
				$response['status'] = 0;
				echo json_encode($response);exit;
				//break;
			}
			foreach ($productIds as $key => $productId) {
				$order = Mage::getResourceModel('sales/order_item_collection')->addAttributeToFilter('product_id', array('eq' => $productId))->load();
				$order->getSelect()->join(array('od' => 'sales_flat_order'), 'od.entity_id = main_table.order_id', array('status'))->where('od.status = "pending"');
				if($order->getSize() < 1)
				{
					$this->IsupdateVirtualManager($productId);
					$collection = Mage::getResourceModel('sales/order_item_collection')->addAttributeToFilter('product_id', array('eq' => $productId))->load();
					$product = Mage::getModel('catalog/product')->load($productId);
					$product->setPrice($product->getCustomPrice());
					$product->setTaxClassId(2);
					$optionId = 0;
					$options = array();
					foreach ($product->getOptions() as $option) {
						$optionId = $option->getOptionId();
						$optionValue = $option->getValues();
						$options[$optionId] = $optionValue;
					}
					$buyInfo = array(
						'qty' => 1,
						'options' => $options,
					);
					$quote->addProduct($product, new Varien_Object($buyInfo));
				}
			}
			$billingAddressData = $quote->getBillingAddress()->addData($customerBillingAddress);
			$shippingAddressData = $quote->getShippingAddress()->addData($customerShippingAddress);
			$shippingAddressData->setCollectShippingRates(true)->collectShippingRates();

			$shippingAddressData->setShippingMethod($shippingMethod)->setPaymentMethod($paymentMethod);
			$quote->getPayment()->importData(array('method' => $paymentMethod));
			$TaxAmount = $quote->getShippingAddress()->getData('tax_amount');
			
			if ($quote->getSubtotal() >= 200000 && $paymentMode == "Cash") {
				$message = "You can't generate Invoice with Cash on delivery Payment mode as Order amount exceeds 2 Lacs.";
				$response['status'] = 2;
				$response['message'] = $message;
				echo json_encode($response);exit;
			}
			// For DISCOUNT DIVIDED BY ITEM IN ADMIN - START
			if (!empty($discountValue) && $discountType=='percent') {
				$percentdisc = $discountValue;
				$finalamt = $quote->getSubtotal();
				$discountamt = ($finalamt * $percentdisc) / 100;
			} else if(!empty($discountValue) && $discountType=='amount'){
				$itemcount = $quote->getItemsCount();
				$discountamt = $discountValue / $itemcount;
			}
			// FOR DISCOUNT DIVIDED BY ITEM IN ADMIN - END
			$quote->collectTotals()->save();
			// For Set Final Total In Admin - Start 
			if (!empty($discountValue) && $discountType=='percent') {
				$gtotal = $quote->getSubtotal();
				$discountindividuals = ($gtotal * $quote->getCustomDiscountPercent() / 100);
				$discountindividual = $discountindividuals;
				$FinalGrandTotal = ($gtotal + $TaxAmount) - $discountindividual;
			} else {
				$gtotal = $quote->getSubtotal();
				$FinalGrandTotal = ($gtotal + $TaxAmount);
			}
			if (!empty($discountValue)) {
				$discountindividual = $quote->getCustomDiscountAmount();
				$gtotal = $quote->getSubtotal();
				$FinalGrandTotal = ($gtotal + $TaxAmount) - $discountindividual;
			} else {
				$gtotal = $quote->getSubtotal();
				$FinalGrandTotal = ($gtotal + $TaxAmount);
			}
			foreach ($quote->getAllAddresses() as $address) {
				$address->setDiscountAmount($discountindividual);
				$address->setBaseDiscountAmount($discountindividual);
				$address->setGrandTotal($FinalGrandTotal);
				$address->setBaseGrandTotal($FinalGrandTotal);
				$address->save();
			}
			$service = Mage::getModel('sales/service_quote', $quote);
			$service->submitAll();
			$order = $service->getOrder();
			$lastOrder = Mage::getModel('sales/order')->getCollection()
				       ->setOrder('entity_id','DESC')
				       ->setPageSize(1)
				       ->getFirstItem();
			$memoOrders[] = $lastOrder->getEntityId();
			$memoOrders = array_unique($memoOrders);

			if(count($memoOrders) > 0)
			{
				foreach ($productIds as $key => $productId) {
					$status = '';
					$statusLabel = '';
					$inventory_status = Mage::getModel('eav/config')->getAttribute('catalog_product','inventory_status');
					$inventory_status = Mage::getModel('eav/entity_attribute_source_table')->setAttribute($inventory_status)->getAllOptions(false);
								
					foreach($inventory_status as $inventory_status)
					{
							if(trim(strtolower($inventory_status['label'])) == 'out') 
							{
								$status = $inventory_status['value'];
								$statusLabel = $inventory_status['label'];
							}
					}
					$query = "UPDATE catalog_product_flat_1 SET `approval_memo_generated` = '1',`return_memo_generated` = '0',`inventory_status`='".$status."',inventory_status_value='".$statusLabel."'  WHERE entity_id=" . $productId;
	        		$write->query($query);
					Mage::helper('virtualproductmanager')->getChangeproductstatus($productId, "out");
					/*$queryupd = "UPDATE catalog_product_flat_1 SET `return_memo_generated` = '0'  WHERE entity_id=" . $productId;
					$write->query($queryupd);*/
				}
				foreach ($memoOrders as $memoOrder) {
					$resource = Mage::getSingleton('core/resource');
				    $readConnection = $resource->getConnection('core_read');
				    $query = "select approval_memo_number from sales_flat_order where approval_memo_number is not null order by entity_id desc limit 1";
				    $result = $readConnection->fetchCol($query);

				    $findquery = "select approval_memo_number from sales_flat_order where approval_memo_number is not null and approval_memo_number = '19-20/106' order by entity_id desc limit 1";
				    $findresult = $readConnection->fetchCol($findquery);
				    if((!empty($findresult[0]))){
				    	if(count($result) > 0){
					    	if((!empty($result[0])))
						    {					     
							        $memoNumber = $result[0];
							        $finalnumber = array_pop(explode('/', $memoNumber));
							        $memofinal = $finalnumber+1;
							        $returnNumber = str_replace('19-20/106','','19-20/'.$memofinal);
							}else{
					        	$returnNumber = "19-20/106";
					      	}
					    }else{
				        	$returnNumber = "19-20/106";
				      	}
				    }else{
				    	$returnNumber = "19-20/106";
				    }
				    if(!empty($approvalNumber))
				    	$returnNumber = $approvalNumber;
				    
				    $order = Mage::getModel('sales/order')->load($memoOrder);
				    if(!empty($approvalDate))
				    	$order->setCreatedAt(date('Y-m-d H:i:s',strtotime($approvalDate)));
				    $order->setApprovalMemoNumber($returnNumber);
				    $order->setApprovalType($approvalType);

					$order->setSelectedFranchiseId($franchiseId);
					$order->setState(Mage_Sales_Model_Order::STATE_NEW, true);
					$order->setQrProductStatus(1);
					$saved = $order->save();
					//echo $lastOrder->getEntityId();exit;
				}
			}
			if(count($memoOrders) > 0)
			{
				$response['status'] = 1;
				$response['message'] = 'Memo Generated Successfully';	
			}
			else
			{
				$response['status'] = 0;
				$response['message'] = 'Something went wrong! Please try again later!';		
			}
			
			echo json_encode($response);exit;
		}
	}
	//Generate return memo
	public function generatereturnmemoAction()
	{
		$params = Mage::app()->getRequest()->getParams();
		$productIds = isset($params['productIds']) ? $params['productIds'] : array();
		$index = 0;
		//$orderFranchiseID = array();
		//echo "<pre>";
		if (strpos($productIds, ',') !== false) {
		    $productIds = explode(',', $productIds);
		}
		else
		{
			$productIds = array($productIds);	
		}
		foreach ($productIds as $key => $productId) {
			$orderCollection = Mage::getResourceModel('sales/order_item_collection')
					->addAttributeToFilter('product_id', array('eq' => $productId))->load();
			$orderCollection->addAttributeToSelect('order_id');

			$orderCollection->getSelect()->join(array('od' => 'sales_flat_order'), 'od.entity_id = main_table.order_id', array('status'))->where('od.status = "pending"');
			$collection_data = $orderCollection->getData();
			$order_ids = $collection_data;
			$order_id = isset($order_ids[0]['order_id']) ? $order_ids[0]['order_id'] : '';
			
			if(!empty($order_id))
			{
				$ordersObj = Mage::getModel('sales/order')->load($order_id);
				$collection = Mage::getResourceModel('sales/order_item_collection')
					->addAttributeToFilter('order_id', array('eq' => $order_id))->load();
				$collection->getSelect()->join(array('od' => 'sales_flat_order'), 'od.entity_id = main_table.order_id', array('status'))->where('od.status = "pending"');
				$countitem = $collection->getSize();
				if ($countitem > 1) {
					$items = $ordersObj->getAllItems();
					foreach ($items as $item) {
						if ($item->getProductId() == $productId) {
							$item->delete();
							$ordersObj->save();
						}
					}
					$ordersObj->setState(Mage_Sales_Model_Order::STATE_NEW, true)->save();
				}
				else
				{
					$ordersObj->setState(Mage_Sales_Model_Order::STATE_CANCELED, true)->save();
				}
				$memonumber[$index] = $ordersObj->getApprovalMemoNumber();
				$orderCustomerID[$index] = $ordersObj->getData('customer_id');
				//selected_franchise_id
				$orderFranchiseID[$index] = $ordersObj->getData('selected_franchise_id');
				//print_r($ordersObj->getData());exit;
				$orderCustomer = Mage::getModel("customer/customer")->load($orderFranchiseID[$index]);
				$franchiseFirstName = $orderCustomer->getData('firstname');
				$franchiseLastName = $orderCustomer->getData('lastname');
				$franchiseData[] = $franchiseFirstName."  ".$franchiseLastName;
				$orderCustomerFranchiseName[$index] = $orderFranchiseID[$index];
				$orderdefaultBilling[$index] = $orderCustomer->getDefaultBilling();
				$_products = Mage::getModel('catalog/product')->load($productId);
				$attributeSetModel = Mage::getModel("eav/entity_attribute_set");
				$attributeSetModel->load($_products->getAttributeSetId());
				$attributeSetName = $attributeSetModel->getAttributeSetName();
				$_productmetal_list = Mage::getModel('metal/metalquality')->getCollection()
					->addFieldToSelect('metal_quality')
					->addFieldToFilter('grp_metal_quality_id', $_products->getMetalQuality());
				$productmetalarr_list = $_productmetal_list->getData();
				$product_metalquality = $productmetalarr_list[0]['metal_quality'];
				$productQty = 1;
				$price = $_products->getCustomPrice();

				$stone = $_products->getRtsStoneQuality();
				$data = Mage::helper('stone')->getSideStoneData($_products->getId(), $stone);
				$gemdata = Mage::helper('stone')->getGemStoneData($_products->getId());
				$diamondswt = $data['totalcts'][0] * $productQty;
				$metalswt = $_products->getMetalWeight();
				$totQty += $productQty;
				$totdiamondswt += $diamondswt;
				$totmetalswt += $metalswt;
				$totgrandtotalprice += $price;

				$finalgrandtotalprice = Mage::helper('core')->currencyByStore((int) $totgrandtotalprice,
					Mage::app()->getStore(), true, false);
				$arrayitem[$orderFranchiseID[$index]][$index]['productid'] = $productId;
				$arrayitem[$orderFranchiseID[$index]][$index]['product_types'] = $attributeSetName;
				$arrayitem[$orderFranchiseID[$index]][$index]['kt'] = $product_metalquality . "/" . isset($arrayitem[$orderFranchiseID[$index]][$index]['kt']) ? $arrayitem[$orderFranchiseID[$index]][$index]['kt'] : "";

				$arrayitem[$orderFranchiseID[$index]][$index]['kt'] = $product_metalquality . " /" . (isset($arrayitem[$orderFranchiseID[$index]][$index]['kt']) ? $arrayitem[$orderFranchiseID[$index]][$index]['kt'] : "");

				$arrayitem[$orderFranchiseID[$index]][$index]['qty'] = intval($arrayitem[$orderFranchiseID[$index]][$index]['qty']) + round($productQty, 0);
				$arrayitem[$orderFranchiseID[$index]][$index]['diamond_weight'] = floatval($diamondswt) + floatval(isset($arrayitem[$orderFranchiseID[$index]][$index]['diamond_weight']) ? $arrayitem[$orderFranchiseID[$index]][$index]['diamond_weight'] : 0);
				$arrayitem[$orderFranchiseID[$index]][$index]['metal_weight'] = floatval($metalswt) + floatval(isset($arrayitem[$orderFranchiseID[$index]][$index]['metal_weight']) ? $arrayitem[$orderFranchiseID[$index]][$index]['metal_weight'] : 0);
				$arrayitem[$orderFranchiseID[$index]][$index]['price'] = intval($arrayitem[$orderFranchiseID[$index]][$index]['price']) + intval($price);
				// For Status change return memo
				Mage::helper('virtualproductmanager')->getChangeproductstatus($productId, "in");
				$write = Mage::getSingleton("core/resource")->getConnection("core_write");
				$status = '';
				$statusLabel = '';
				$inventory_status = Mage::getModel('eav/config')->getAttribute('catalog_product','inventory_status');
				$inventory_status = Mage::getModel('eav/entity_attribute_source_table')->setAttribute($inventory_status)->getAllOptions(false);
							
				foreach($inventory_status as $inventory_status)
				{
						if(trim(strtolower($inventory_status['label'])) == 'in') 
						{
							$status = $inventory_status['value'];
							$statusLabel = $inventory_status['label'];
						}
				}
				$query = "UPDATE catalog_product_flat_1 SET `approval_invoice_generated` = '0',`approval_memo_generated` = '0',`inventory_status`='".$status."',inventory_status_value='".$statusLabel."'  WHERE entity_id=" . $productId;
				$write->query($query);
				$index++;
			}
			
		}
		$arrayIndex = 0;
		$franchiseid = '';
		$productIds = array();
		$franchiseID = '';
		foreach ($orderFranchiseID as $key => $value) {
			$productidsArray = array();
			if ($franchiseID != $value) {
				foreach ($arrayitem[$value] as $finalKey => $product) {
					$productidsArray[] = $product['productid'];
				}
				$productIds[$value] = implode(',', $productidsArray);
			}
			$franchiseID = $value;
		}
		
		foreach ($orderFranchiseID as $key => $value) {
			$returnMemo = array();
			$orderCustomer = Mage::getModel("customer/customer")->load($value);
			$franchiseFirstName = $orderCustomer->getData('firstname');
			$franchiseLastName = $orderCustomer->getData('lastname');
			$returnMemo['customer_id'] = $orderCustomerID[$arrayIndex];
			$returnMemo['franchise_id'] = $value;
			$returnMemo['franchise_name'] = $franchiseFirstName." ".$franchiseLastName;
			$returnMemo['franchise_address'] = $orderdefaultBilling[$arrayIndex];
			$returnMemoProductData = array();
			$returnCounter = 0;
			$grandTotalData = array();

			foreach ($arrayitem[$value] as $finalKey => $memodataRow) {
				$returnMemoProductData[$returnCounter] = $memodataRow;
				$grandTotalData['qty'] = intval($grandTotalData['qty']) + $memodataRow['qty'];
				$grandTotalData['diamond_weight'] = floatval($memodataRow['diamond_weight']) + floatval(isset($grandTotalData['diamond_weight']) ? $grandTotalData['diamond_weight'] : 0);
				$grandTotalData['metal_weight'] = floatval($memodataRow['metal_weight']) + floatval(isset($grandTotalData['metal_weight']) ? $grandTotalData['metal_weight'] : 0);
				$grandTotalData['price'] = intval($grandTotalData['price']) + intval($memodataRow['price']);
				$returnCounter++;
			}
			$returnMemo['product_data'] = $returnMemoProductData;
			$returnMemo['grand_total_data'] = json_encode($grandTotalData);
			$returnMemo['product_data'] = json_encode($returnMemoProductData);
			$resource = Mage::getSingleton('core/resource');
			$readConnection = $resource->getConnection('core_read');
			$query = "select return_number from inventory_return_memo order by id desc limit 1";
			$result = $readConnection->fetchCol($query);

			$findquery = "select return_number from inventory_return_memo where return_number = '19-20/001' order by id desc limit 1";
			$findresult = $readConnection->fetchCol($findquery);
			if ((!empty($findresult[0]))) {
				if (count($result) > 0) {
					if ((!empty($result[0]))) {
						$rememoNumber = $result[0];
						$finalnumber = array_pop(explode('/', $rememoNumber));

						$rememofinal = (int) $finalnumber + 1;
						//var_dump($rememofinal);exit;
						if (is_numeric($rememofinal) && $rememofinal > 0) {
							$increStr = (string) $rememofinal;
							$increStr = str_pad($increStr, 3, "0", STR_PAD_LEFT);
							$returnNumber = '19-20/' . $increStr;
						}
						//$returnNumber = str_replace('19-20/001', '', '19-20/00' . $rememofinal);
					} else {
						$returnNumber = "19-20/001";
					}
				} else {
					$returnNumber = "19-20/001";
				}
			} else {
				$returnNumber = "19-20/001";
			}
			//if ($franchiseid != $value) {
				//print_r($returnMemo);exit;
				$Productinsertdata = $resource->getConnection('core_write');
				$insert = "INSERT INTO inventory_return_memo (customer_id,franchise_id,franchise_name,franchise_address,product_data,product_ids,grand_total_data,return_number,approval_memo_number,created_date,modified_date,status) VALUES ('" . $orderCustomerID[$arrayIndex] . "','" . $value . "','" . $franchiseData[$key]. "','" . $orderdefaultBilling[$arrayIndex] . "','" . $returnMemo['product_data'] . "','" . $productIds[$value] . "','" . $returnMemo['grand_total_data'] . "','" . $returnNumber . "','" . $memonumber[$arrayIndex] . "','" . date('Y-m-d H:i:s') . "','" . date('Y-m-d H:i:s') . "','1')";
				//echo $insert;exit;
				$Productinsertdata->query($insert);
			//}
			$franchiseid = $value;
			$arrayIndex++;
		}
		$message = "Return Memo Successfully";
		$response['status'] = 1;
		$response['message'] = $message;
		echo json_encode($response);exit;
	}
	//Remove memo product
	public function removeMemoProductAction()
	{	
		$params = Mage::app()->getRequest()->getParams();

		$orderId = isset($params['orderId']) ? $params['orderId'] : '';
		$productId = isset($params['productId']) ? $params['productId'] : '';
		
		$orderCollection = Mage::getModel('sales/order')->load($orderId);
		$write = Mage::getSingleton("core/resource")->getConnection("core_write");
		$query = "DELETE FROM grp_qradd_product WHERE pro_id=" . $productId;
		$write->query($query);
		foreach ($orderCollection->getAllItems() as $item) {
			if ($item->getProductId() == $productId) {
				$subTotal = $orderCollection->getSubtotal() - $item->getPrice();
				$taxAmt = $orderCollection->getTaxAmount();
				$newTaxAmt = $taxAmt - $item->getTaxAmount();
				$discountAmt = $orderCollection->getDiscountAmount();
				$grandTotal = $taxAmt + ($subTotal - $discountAmt);
				$orderCollection->setTaxAmount($newTaxAmt);
				$orderCollection->setSubtotal($subTotal);
				$orderCollection->setGrandTotal($grandTotal);
				$orderCollection->setBaseGrandTotal($grandTotal);

				$invoices = $orderCollection->getInvoiceCollection();
				foreach ($invoices as $invoice) {
					$items = $invoice->getAllItems();
					foreach ($items as $iteminvoice) {
						if ($iteminvoice->getProductId() == $productId) {
							$subTotal = $invoice->getSubtotal() - $iteminvoice->getPrice();
							$taxAmt = $invoice->setTaxAmount();
							$newTaxAmt = $taxAmt - $iteminvoice->getTaxAmount();
							$discountAmt = $orderCollection->getDiscountAmount();
							$grandTotal = $taxAmt + ($subTotal - $discountAmt);
							$invoice->setTaxAmount($newTaxAmt);
							$invoice->setDiscountAmount($discountAmt);
							$invoice->setSubtotal($subTotal);
							$invoice->setGrandTotal($grandTotal);
							$invoice->setBaseGrandTotal($grandTotal);
							$iteminvoice->delete();
							$iteminvoice->save();
						}
					}
				}
				$item->delete();
				$status = '';
				$statusLabel = '';
				$inventory_status = Mage::getModel('eav/config')->getAttribute('catalog_product','inventory_status');
				$inventory_status = Mage::getModel('eav/entity_attribute_source_table')->setAttribute($inventory_status)->getAllOptions(false);
							
				foreach($inventory_status as $inventory_status)
				{
						if(trim(strtolower($inventory_status['label'])) == 'in') 
						{
							$status = $inventory_status['value'];
							$statusLabel = ucfirst($inventory_status['label']);
						}
				}
				$query = "UPDATE catalog_product_flat_1 SET `approval_invoice_generated` = '1',`inventory_status`='".$status."',inventory_status_value='".$statusLabel."' WHERE entity_id=".$productId;
				$write->query($query);

				$query = "UPDATE qrcode_inventory_management SET inventory_status='".$statusLabel."' WHERE pr_id=".$productId;
				$write->query($query);
			}
		}
		$orderCollection->save();
		$response['status'] = true;
		$response['message'] = 'Product has beed removed successfully!';
		echo json_encode($response);exit;
	}
	public function reGenerateInvoiceAction()
	{
		$params = Mage::app()->getRequest()->getParams();	
		$orderId = isset($params['orderId']) ? $params['orderId'] : '';
		$paymentData = json_decode($params['paymentData']);
		$productIds = isset($paymentData->product_ids) ? $paymentData->product_ids : '';
		if (strpos($productIds, ',') !== false) {
		    $productIds = explode(',', $productIds);
		}
		else
		{
			$productIds = array($productIds);	
		}
		$customerId = isset($params['customerId']) ? $params['customerId'] : '';
    	$operationType = isset($params['operationType']) ? $params['operationType'] : '';
    	$paymentMode = isset($paymentData->payment_mode) ? $paymentData->payment_mode : '';
    	$discountType = isset($paymentData->discount_type) ? $paymentData->discount_type : '';
    	$discountValue = isset($paymentData->discount_value) ? $paymentData->discount_value : '';
    	$franchiseId = isset($paymentData->franchise_id) ? $paymentData->franchise_id : '';
    	$franchiseName = isset($paymentData->franchise_name) ? $paymentData->franchise_name : '';
    	$franchiseCommision = isset($paymentData->franchise_commision) ? $paymentData->franchise_commision : '';
    	$agentName = isset($paymentData->agent_name) ? $paymentData->agent_name : '';
    	$agentCommission = isset($paymentData->agent_commision) ? $paymentData->agent_commision : '';
    	$store = Mage::app()->getStore();
		$website = Mage::app()->getWebsite();

		$customer = Mage::getModel("customer/customer")->load($customerId);
		$defaultBilling = $customer->getDefaultBilling();
		$address = Mage::getModel("customer/address")->load($defaultBilling);
		$customerBillingAddress = $customer->getPrimaryBillingAddress()->getData();
		$customerShippingAddress = $customer->getPrimaryShippingAddress()->getData();
		$shippingMethod = 'freeshipping_freeshipping';
		$paymentMethod = 'checkmo';
		$resource = Mage::getSingleton('core/resource');
		$writeConnection = $resource->getConnection('core_write');
		$readConnection = $resource->getConnection('core_read');
		if(!empty($orderId))
		{
			$orderCollection = Mage::getModel('sales/order')->load($orderId);
			$taxAmount = $orderCollection->getTaxAmount();

			if ($discountType == 'percent' && !empty($discountValue)) {
				$orderCollection->setCustomDiscountPercent($discountValue);
				$orderCollection->setCustomDiscountAmount(0);

			}
			if ($discountType == 'amount' && !empty($discountValue)) {
				$orderCollection->setCustomDiscountAmount($discountValue);
				$orderCollection->setCustomDiscountPercent(0);
			}
			if ($discountType == 'percent' && !empty($discountValue)) {
				$percentdisc = $discountValue;
				$finalamt = (float)$orderCollection->getSubtotal();
				$discountamt = (float)($finalamt * (float)$percentdisc) / 100;
			} else {
				$discountamt = (float)$discountValue;
			}
			//echo $discountType."  ".$finalamt."  ".$discountamt."  ".$percentdisc;exit;
			if ($discountType == 'percent' || !empty($discountValue)) {
				$gtotal = $orderCollection->getSubtotal();
				$discountindividuals = ($gtotal * $orderCollection->getCustomDiscountPercent() / 100);
				$discountindividual = $discountindividuals;
				$FinalGrandTotal = ($gtotal + $taxAmount) - $discountindividual;
			}
			else
			{
				$gtotal = $orderCollection->getSubtotal();
				$FinalGrandTotal = ($gtotal + $TaxAmount);
			}

			if ($discountType == 'amount' || !empty($discountValue)) {
				$discountindividual = $orderCollection->getCustomDiscountAmount();
				$gtotal = $orderCollection->getSubtotal();
				$FinalGrandTotal = ($gtotal + $taxAmount) - $discountindividual;
			}
			if (!empty($discountValue)) {
				$discountindividual = $orderCollection->getCustomDiscountAmount();
				$gtotal = $orderCollection->getSubtotal();
				$FinalGrandTotal = ($gtotal + $TaxAmount) - $discountindividual;
			} else {
				$gtotal = $orderCollection->getSubtotal();
				$FinalGrandTotal = ($gtotal + $TaxAmount);
			}
			foreach ($orderCollection->getAllAddresses() as $address) {
				$address->setDiscountAmount($discountindividual);
				$address->setBaseDiscountAmount($discountindividual);
				$address->setGrandTotal($FinalGrandTotal);
				$address->setBaseGrandTotal($FinalGrandTotal);
				$address->save();
			}
			
			if (!empty($discountValue) && $discountType=='percent') {
				$orderCollection->setCustomDiscountPercent($discountValue);
			}
			if(!empty($discountValue) && $discountType=='amount'){
				$orderCollection->setCustomDiscountAmount($discountValue);
			}
			$orderCollection->save();
			$order = Mage::getModel('sales/order')->load($orderCollection->getData('entity_id'));
			foreach ($orderCollection->getAllItems() as $item) {
				$item->setDiscountAmount($discountamt);
				$item->setBaseDiscountAmount($discountamt);
				$productID = $item->getProductId();
				$Checkvalue = "Select * from `qrcode_inventory_management` where pr_id =" . $productID;
				$rs = $readConnection->fetchOne($Checkvalue);
				if (empty($rs)) {
					$query = "INSERT INTO `qrcode_inventory_management` (`pr_id`,`pr_sku`,`pr_name`,`inventory_status`,`soldout_date`,`release_date`) VALUES ('" . $productID . "', '" . $item->getSku() . "','" . $item->getName() . "','sold out','" . date('Y-m-d') . "','" . date('Y-m-d') . "')";
					$writeConnection->query($query);
				} else {
					$write = Mage::getSingleton("core/resource")->getConnection("core_write");
					$query = "UPDATE qrcode_inventory_management SET `pr_id` = '" . $productID . "', `pr_sku` = '" . $item->getSku() . "', `pr_name` = '" . $item->getName() . "', `inventory_status` = 'sold out', `soldout_date` = '" . date('Y-m-d') . "', `release_date` = '" . date('Y-m-d') . "' WHERE pr_id=" . $productID;
					$write->query($query);
				}
				$InventoryStatus = Mage::getStoreConfig('virtualproductmanager/qrinventorymngmt/currentmode');
				Mage::helper('virtualproductmanager')->getChangeproductstatus($productID, "sold out");
				if (!empty($productID)) {
					$this->deleteProductInvoice($productID);
				}
			}
			$incrementId = $orderCollection->getRealOrderId();
			$invoice = Mage::getModel('sales/service_order', $orderCollection)->prepareInvoice();
			$invoice->setRequestedCaptureCase(Mage_Sales_Model_Order_Invoice::CAPTURE_ONLINE);
			$invoice = $invoice->register();
				$transactionSave = Mage::getModel('core/resource_transaction')->addObject($invoice)
					->addObject($invoice->getOrder());
			$transactionSave->save();
			$newFranchiseIncrId = str_replace(substr($incrementId, 0, 2), '11', $incrementId);
			$order = Mage::getModel('sales/order')->loadByIncrementId($incrementId);
			$order->setPaymentMode($paymentMode);
			$order->setFranchiseOrderIncrementId($newFranchiseIncrId);
			$order->setAgentName($agentName);
			$order->setSelectedFranchiseId($franchiseId);
			$order->setSelectedFranchiseCommission($franchiseCommision);
			$order->setAgentCommission($agentCommision);
			$order->setQrProductStatus(1);
			$order->setData('state', "complete");
			$order->setStatus("complete");
			/*INVOICE CODE END*/
			$query = "select approval_memo_number from sales_flat_invoice where approval_memo_number is not null order by entity_id desc limit 1";
		    $result = $readConnection->fetchCol($query);
		    $findquery = "select approval_memo_number from sales_flat_invoice where approval_memo_number is not null and approval_memo_number = '19-20/106' order by entity_id desc limit 1";
		    $findresult = $readConnection->fetchCol($findquery);
		    if((!empty($findresult[0]))){
		    	if(count($result) > 0){
			    	if((!empty($result[0])))
				    {					     
					        $memoNumber = $result[0];
					        $finalnumber = array_pop(explode('/', $memoNumber));
					        $memofinal = $finalnumber+1;
					        $returnNumber = str_replace('19-20/106','','19-20/'.$memofinal);
					}else{
			        	$returnNumber = "19-20/106";
			      	}
			    }else{
		        	$returnNumber = "19-20/106";
		      	}
		    }else{
		    	$returnNumber = "19-20/106";
		    }
		    $invoice->setApprovalMemoNumber($returnNumber);
			$invoice->save();	
			//$orderObj->setState(Mage_Sales_Model_Order::STATE_NEW, true);
			$order->save();
		}
		$response['status'] = 1;
		$response['order_id'] = $incrementId;
		$response['message'] = 'Invoice Generated Successfully...';
		echo json_encode($response);exit;
	}
	public function reGenerateMemoAction()
	{
		$params = Mage::app()->getRequest()->getParams();
		$orderId = isset($params['orderId']) ? $params['orderId'] : '';
		$paymentData = json_decode($params['paymentData']);

		$customerId = isset($params['customerId']) ? $params['customerId'] : '';
    	$operationType = isset($params['operationType']) ? $params['operationType'] : '';
    	$paymentMode = isset($paymentData->payment_mode) ? $paymentData->payment_mode : '';
    	$discountType = isset($paymentData->discount_type) ? $paymentData->discount_type : '';
    	$discountValue = isset($paymentData->discount_value) ? $paymentData->discount_value : '';
    	$franchiseId = isset($paymentData->franchise_id) ? $paymentData->franchise_id : '';
    	$franchiseName = isset($paymentData->franchise_name) ? $paymentData->franchise_name : '';
    	$franchiseCommision = isset($paymentData->franchise_commision) ? $paymentData->franchise_commision : '';
    	$agentName = isset($paymentData->agent_name) ? $paymentData->agent_name : '';
    	$agentCommission = isset($paymentData->agent_commision) ? $paymentData->agent_commision : '';
    	$store = Mage::app()->getStore();
		$website = Mage::app()->getWebsite();

		$customer = Mage::getModel("customer/customer")->load($customerId);
		$defaultBilling = $customer->getDefaultBilling();
		$address = Mage::getModel("customer/address")->load($defaultBilling);
		$customerBillingAddress = $customer->getPrimaryBillingAddress()->getData();
		$customerShippingAddress = $customer->getPrimaryShippingAddress()->getData();
		if(!empty($orderId))
		{
			$orderCollection = Mage::getModel('sales/order')->load($orderId);
			$taxAmount = $orderCollection->getTaxAmount();

			if ($discountType == 'percent' || !empty($discountValue)) {
				$orderCollection->setCustomDiscountPercent($discountValue);
				$orderCollection->setCustomDiscountAmount(0);

			}
			if ($discountType == 'amount' || !empty($discountValue)) {
				$orderCollection->setCustomDiscountAmount($discountValue);
				$orderCollection->setCustomDiscountPercent(0);
			}
			if ($discountType == 'percent' || !empty($discountValue)) {
				$percentdisc = $discountValue;
				$finalamt = $orderCollection->getSubtotal();
				$discountamt = ($finalamt * $percentdisc) / 100;
			} else {
				$discountamt = $discountValue;
			}
			if ($discountType == 'percent' || !empty($discountValue)) {
				$gtotal = $orderCollection->getSubtotal();
				$discountindividuals = ($gtotal * $orderCollection->getCustomDiscountPercent() / 100);
				$discountindividual = $discountindividuals;
				$FinalGrandTotal = ($gtotal + $taxAmount) - $discountindividual;
			}
			else
			{
				$gtotal = $orderCollection->getSubtotal();
				$FinalGrandTotal = ($gtotal + $TaxAmount);
			}

			if ($discountType == 'amount' || !empty($discountValue)) {
				$discountindividual = $orderCollection->getCustomDiscountAmount();
				$gtotal = $orderCollection->getSubtotal();
				$FinalGrandTotal = ($gtotal + $taxAmount) - $discountindividual;
			}
			if (!empty($discountValue)) {
				$discountindividual = $orderCollection->getCustomDiscountAmount();
				$gtotal = $orderCollection->getSubtotal();
				$FinalGrandTotal = ($gtotal + $TaxAmount) - $discountindividual;
			} else {
				$gtotal = $orderCollection->getSubtotal();
				$FinalGrandTotal = ($gtotal + $TaxAmount);
			}
			foreach ($orderCollection->getAllAddresses() as $address) {
				$address->setDiscountAmount($discountindividual);
				$address->setBaseDiscountAmount($discountindividual);
				$address->setGrandTotal($FinalGrandTotal);
				$address->setBaseGrandTotal($FinalGrandTotal);
				$address->save();
			}
			$orderCollection->setAgentName($agentName);
			$orderCollection->setAgentCommission($agentCommission);
			foreach ($orderCollection->getAllItems() as $item) {
				$item->setDiscountAmount($discountamt);
				$item->setBaseDiscountAmount($discountamt);
				$item->setGrandTotal($FinalGrandTotal);
				$item->setBaseGrandTotal($FinalGrandTotal);
				$item->save();
			}
			$orderCollection->setSelectedFranchiseId($franchiseId);
			$orderCollection->setSelectedFranchiseCommission($franchiseCommision);
			$orderCollection->setAgentName($agentName);
			$orderCollection->setAgentCommission($agentCommission);
			$orderCollection->setQrProductStatus(1);

			$orderCollection->setDiscountAmount($discountamt);
			$orderCollection->setBaseDiscountAmount($discountamt);
			$orderCollection->setDiscountInvoiced($discountamt);
			$orderCollection->setBaseDiscountInvoiced($discountamt);

			$orderCollection->setGrandTotal($FinalGrandTotal);
			$orderCollection->setBaseGrandTotal($FinalGrandTotal);

			$invoiceCollection = $orderCollection->getInvoiceCollection()->getAllIds();
			if(!empty($invoiceCollection))
			{
				$invoice = Mage::getModel('sales/order_invoice')->load($invoiceCollection[0]);
				foreach ($invoice->getAllItems() as $item) {
					$item->setDiscountAmount($discountamt);
					$item->setBaseDiscountAmount($discountamt);
					$item->setGrandTotal($FinalGrandTotal);
					$item->setBaseGrandTotal($FinalGrandTotal);
					$item->save();
				}
				foreach ($invoice->getAllAddresses() as $address) {
					$address->setDiscountAmount($discountindividual);
					$address->setBaseDiscountAmount($discountindividual);
					$address->setGrandTotal($FinalGrandTotal);
					$address->setBaseGrandTotal($FinalGrandTotal);
					$address->save();
				}
				$invoice->setDiscountAmount($discountamt);
				$invoice->setBaseDiscountAmount($discountamt);
				$invoice->setDiscountInvoiced($discountamt);
				$invoice->setBaseDiscountInvoiced($discountamt);
				$invoice->setGrandTotal($FinalGrandTotal);
				$invoice->setBaseGrandTotal($FinalGrandTotal);
				$invoice->save();
			}
			
			$newFranchiseIncrId = str_replace(substr($orderCollection->getIncrementId(), 0, 2), '11', $orderCollection->getIncrementId());
			$orderCollection->setFranchiseOrderIncrementId($newFranchiseIncrId);
			$orderCollection->save();
			$message = '';
			if($operationType == 'invoice')
			{
				$message = 'Invoice Updated';
			}
			else
			{
				$message = 'Memo Updated';
			}
			$response['status'] = true;
			$response['message'] = $message;
			$response['orderid'] = $orderId;
			echo json_encode($response);exit;
		}
	}
}