<?php
class Grp_Dmlapi_TransactionController extends Mage_Core_Controller_Front_Action{
	
	public function IndexAction() {     
      
        echo "in dml api customers";exit;       
    }

    public function TransactionviewAction()
    {
    	$pagesize = $this->getRequest()->getParam('pagesize');
		$customerId = $this->getRequest()->getParam('customer_id');
		/*[[Start Total for creadit debit]]*/
    	$collection = Mage::getModel("accountdetail/accountdetail")->getCollection()->addFieldToFilter('franchises_id',$customerId)->addFieldToSelect('credit')->getColumnValues('credit');
		$total_credit = array_sum($collection);
		
		$collection = Mage::getModel("accountdetail/accountdetail")->getCollection()->addFieldToFilter('franchises_id',$customerId)->addFieldToSelect('deposite')->getColumnValues('deposite');
		$total_deposite = array_sum($collection);
		
		$collection = Mage::getModel("accountdetail/accountdetail")->getCollection()->addFieldToFilter('franchises_id',$customerId)->addFieldToSelect('debit')->getColumnValues('debit');
		$total_debit = array_sum($collection);
		
    	/*[[End Total for creadit debit]]*/
		$final_totalamount = abs($total_credit) - abs($total_debit); 
		$collection = Mage::getModel("accountdetail/accountdetail")->getCollection()->addFieldToFilter('franchises_id',$customerId)->addFieldToSelect('tds')->getColumnValues('tds');
		$total_tds = array_sum($collection);
		$transaction_collection = Mage::getModel("accountdetail/accountdetail")->getCollection()->addFieldToFilter('franchises_id',$customerId)->setPageSize(10)->setCurPage($pagesize);
		if($transaction_collection->getSize() > 0)
		{
			$detail = array();
			if(($transaction_collection->getSize()+10) > ($pagesize*10)) {
			foreach ($transaction_collection as $data)
			{	
				/*[[Start for description]]*/
				if($data->getDescription() == 'Credit')
				{
					$description_detail = "CR";
				}
				if($data->getDescription() == 'Debit')
				{
					$description_detail = "DB";
				}
				if($data->getDescription() == 'Deposite')
				{ 
					$description_detail = "DEP";
			    }
				if($data->getDescription() == 'Stock Debit')
				{
					$description_detail = "STDB";
				}
				if($data->getDescription() == 'Stock Credit')
				{
					$description_detail ="STCR";
				}
				if($data->getDescription() == 'Comission Credit')
				{
					$description_detail = "COCR";
				}
				if($data->getDescription() == 'Comission Debit')
				{
					$description_detail = "CODB";
				}
				/*[[End for description]] */

				 /*[[Start for price]] */
				 if($data->getData('credit')) 
				 { 
					$transctionPriceFnl =  abs($data->getData('credit'));
				 }
				 if($data->getData('deposite')) 
				 { 
					$transctionPriceFnl = abs($data->getData('deposite'));
				 }
				 if($data->getData('debit')) 
				 {
					 $transctionPriceFnl =  abs($data->getData('debit'));
				 }
				 if(empty($transctionPriceFnl)) {
				 	$transctionPriceFnl = 0;
				 }
				 if(is_null($transctionPriceFnl)) {
				 	$transctionPriceFnl = 0;	
				 }
				 /*[[End for price]] */
		 		 /* [[Start for popup data]]*/
		 		$child_item_fnl = array();
		 		$params = $data->getData('order_id');
		    	$orderCollection = Mage::getModel('sales/order')->getCollection()->addFieldToFilter(
		    		array('increment_id','franchise_order_increment_id'),array($params,$params)
		    	)->getFirstItem();
				if(count($orderCollection->getData()) > 0 )
				{
					$order = $orderCollection->getEntityId();
			    	$ordCollection = Mage::getModel('sales/order')->load($order);
			    	$orderItems = $ordCollection->getItemsCollection();

			    	foreach ($orderItems as $item)
			    	{
				    	$productId = $item->getProductId();
						$product = Mage::getModel('catalog/product')->load($productId);
				        $child_increment_id = $params; 
				        $product_name = $item->getName(); 
				        $product_sku = $product->getSku(); 
						$attribute = Mage::getModel('eav/config')->getAttribute('catalog_product','metal_quality');
				        $options = $item->getProductOptions(); 
					    $metal_quality = '';                      
					    $metalWeight = '';
		    			if($attributeSetName != 'Rings'){
		    				$metalData = Mage::helper('stone')->getMetalData($productId);
		    				$metalWeight = $metalData['weight'];
		    			}else{
		    				$options1 = Mage::getModel('catalog/product_option')->getProductOptionCollection($product);
		    				foreach ($options1 as $option1) {					
		    					if ($option1->getType() === 'drop_down') {				
		    						$values1 = Mage::getSingleton('catalog/product_option_value')->getValuesCollection($option1);
		    						$ringData = $values1->getData();
		    						if($ringData[0]['title'] == $product->getRtsRingSize()){
		    							$metalWeight = $ringData[0]['metal_weight'];								
		    						}						
		    					}
		    				}
		    			}
			          	if(is_array($options) && is_array($options['options']) && !empty($options['options'])){ 
				          foreach ($options['options'] as  $op){
				          	if($op['label'] == 'STONE QUALITY'){
				          		$product_stonequality =  $product->getRtsStoneQuality();
				          		$stoneData = Mage::helper('stone')->getSideStoneData($item->getProductId(),$op['value']);
				      			if(isset($stoneData['totalweight'][0]) && $stoneData['totalweight'][0] != ''){ 
				      				$product_stoneweight = $stoneData['totalweight'][0].'cts';
				      			}
				             }
			           	}
			      		if($metalWeight != ''){
			              $product_metalweight	 = number_format($metalWeight,2).'gms';
					    }
				        $product_price = $product->getPrice();
			      	}
		   			$child_item_fnl[] = array('product_increment_id'=>$child_increment_id,'product_name'=>$product_name,'product_sku'=>$product_sku,'product_stonequality'=>$product_stonequality,'product_stoneweight'=>$product_stoneweight,'product_price'=>$product_price,'product_metalweight'=>$product_metalweight);
		 		}
				// echo "<pre>";print_r($child_item_fnl);exit;
			}
			
				/*[[End for popup data]]*/
				$increment_id = $data->getData('order_id');
				$create_date  =	$data->getData('create_date');
				$description  =	$description_detail;
				$transction_price = $transctionPriceFnl;
				$childitem[] = 
				$detail[] = array('increment_id'=>$increment_id,'create_date'=>$create_date,'description'=>$description,'transction_price'=>$transctionPriceFnl,'order_item'=>$child_item_fnl);

			}

			echo json_encode(array('status'=>'success','total_deposite'=>$total_deposite,'total_credit'=>$total_credit,'total_debit'=>$total_debit,'final_totalamount'=>$final_totalamount,'total_tds'=>$total_tds,'customer_id'=>$customerId,'data'=>$detail));exit;
			}
			else {
	    	echo json_encode(array('status'=>'failure','customer_id'=>$customerId,'data'=>$detail));exit;	
	   		 }

		}
		else
		{
			echo json_encode(array('status'=>'failure','customer_id'=>$customerId,'data'=>$detail));exit;
		}
	}
}