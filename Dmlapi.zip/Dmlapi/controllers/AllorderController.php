<?php
require_once(Mage::getBaseDir('lib').'/dompdf/autoload.inc.php');
use Dompdf\Dompdf;
class Grp_Dmlapi_AllorderController extends Mage_Core_Controller_Front_Action{
	
	public function orderviewAction()
    {
      $pagesize = $this->getRequest()->getParam('pagesize');
      $customerId = $this->getRequest()->getParam('customer_id'); 
      $customerData =  Mage::getModel('customer/customer')->load($customerId);
	  $order = $this->getRequest()->getParam('order');
	  $group_id = Mage::app()->getRequest()->getParam('group_id');
      $group      = Mage::getModel('customer/group')->load($group_id); 
      $grouprole = $group->getData('customer_group_code');
      $data = array();
      $ordersCollection = array();
      if(!empty($order))
      {
      	  if($group->getCode() == 'Referral' && $customerData->getReferralType() == 'Customer')
      	  {
      	  	   if($order == 'MyOrder')
		       {
		          	$ordersCollection = Mage::getModel("sales/order")->getCollection()
			          ->addFieldToFilter('customer_id',$customerId)
			          ->addAttributeToSort("created_at","DESC")
			          ->addFieldToFilter('is_franchise',1)
			          ->addFieldToFilter('isfranchisee',1)
			          ->setPageSize(10)->setCurPage($pagesize);
				}
				else
				{
					echo json_encode(array('status'=>'failure','customer_id'=>$customerId,'data'=>$data));exit;
				}
				
      	  }
      	  else
      	  {
		      if($order == 'AllOrder')
		      {
		      	$ordersCollection = Mage::getModel("sales/order")->getCollection()
		                  ->addFieldToFilter('customer_id',$customerId)
		                  ->addAttributeToSort("created_at","DESC")
		                  ->setPageSize(10)->setCurPage($pagesize);

		            
		                  
		       }
		       if($order == 'MyOrder')
		       {
		          	$ordersCollection = Mage::getModel("sales/order")->getCollection()
			          ->addFieldToFilter('customer_id',$customerId)
			          ->addAttributeToSort("created_at","DESC")
			          ->addFieldToFilter('is_franchise',1)
			          ->addFieldToFilter('isfranchisee',1)
			          ->setPageSize(10)->setCurPage($pagesize);
				}
		       if($order == 'CustomerOrder')
		       {
		       	   $ordersCollection = Mage::getModel("sales/order")->getCollection()
		                  ->addFieldToFilter('customer_id',$customerId)
		                  ->addAttributeToSort("created_at","DESC")
		                  ->addFieldToFilter('is_franchise',0)
		                  ->addFieldToFilter('isfranchisee',0)
		                  ->setPageSize(10)->setCurPage($pagesize);
				}
				
			}	
			//
			if(($ordersCollection->getSize()+10) > ($pagesize*10)) 
			{
				
				foreach ($ordersCollection as $ordercoll) {
		        	
		         if($ordercoll['customer_group_id'] == 5){
		            $orderid = $ordercoll['increment_id'];
		          }else if($ordercoll['franchise_order_increment_id'] != ''){
		            $orderid = $ordercoll['franchise_order_increment_id'];
		          }else{
		            $orderid = $ordercoll['increment_id'];
		          }
		        	/*[[get product detail from order]]*/ 
		        	$order = Mage::getModel('sales/order')->loadByIncrementId($ordercoll['increment_id']); 
					$items = $order->getItemsCollection()
			              ->addAttributeToSelect('product_id')
			              ->getColumnValues('product_id');
	        		$_productimage = Mage::getModel('catalog/product')->getCollection()->addAttributeToFilter('entity_id',array("in" => $items));
	        		
	        		$img = array();
	        		$order_items = array();
	        		foreach($_productimage as $productimg){ 
	        		  $product = Mage::getModel('catalog/product')->load($productimg->getEntityId());    
			          if(empty($product->getThumbnail())){ 
		                $img =  Mage::helper('catalog/image')->init($product, 'small_image');
		               }else{ 
		                  $img = Mage::getModel('catalog/product_media_config')->getMediaUrl($product->getThumbnail());
		               } 
		               
		               if(strpos($img,"def_2"))
		               {
		               	$urlIm = $img->__toString();
		               }
		               else
		               {
		               	$urlIm = $img;
		               }
		               $product_stonequality = $product->getRtsStoneQuality();
		               if(empty($product_stonequality)) {
		                 $product_stonequality = "";
		           	   }	
		               $product_name = $product->getName();
		               $product_sku = $product->getSku();
		               $side_stone_data=Mage::helper('stone')->getSideStoneData($productimg->getEntityId(),$product->getRtsStoneQuality());
		               $product_stoneweight	= $side_stone_data['totalweight'][0].' ct';
		               $attribute = Mage::getModel('eav/config')->getAttribute('catalog_product','metal_quality');
			           $options = $attribute->getSource()->getAllOptions();
			           $metal_quality = '';                       
			           foreach($options as $key => $value){
			             if($value['value'] == $product->getMetalQuality()){
			               $metal_quality = $value['label'];
			             }
			           } 
						$product_metalquality = $metal_quality;
						/*[[get metal weight]]*/
						$modelmetalproduct = Mage::getModel("stone/metal")->getCollection()->addFieldToFilter('metal_product_id', $productimg->getEntityId());
						foreach ($modelmetalproduct as $metalproduct) {
							$getmetal=$metalproduct->getMetalWeight();
						} 
						$product_metalweight = $getmetal.' gms';
						/*[[get metal weight]]*/
						 if($product->getBangleSize()){
						 $bangleAttr = $product->getResource()->getAttribute('bangle_size');
                		 $bangleSize = $bangleAttr->getSource()->getOptionText($product->getBangleSize());
                		}
                		else
                		{
                			$bangleSize = "";
                		}
                	$order_items[] = array('image'=>$urlIm,'product_sku'=>$product_sku,'product_name'=>$product_name,'product_stonequality'=>$product_stonequality,'product_stoneweight'=>$product_stoneweight,'product_metalweight'=>$product_metalweight,'product_metalquality'=>$product_metalquality,'bangleSize'=>$bangleSize);

					}
					
					/*[[get product detail from order]]*/ 

		        	/*[[get grand total]]*/ 
		        	if($customerData->getInvoiceSetting() == 0 && $group_id == 6){ 
		        	$grand_total = $ordercoll['subtotal'];
			        } else{ 
			           $grand_total = $ordercoll['grand_total'];
			        }
			        /*[[get grand total]]*/

			        if($ordercoll->getData('status') == 'pending') {
			        	$order_status = 'Pending';
			        	
			        }
			        else if($ordercoll->getData('status') == 'canceled') {
			        	$order_status = 'Canceled'; 
			        	
			        }
			        else if($ordercoll->getData('status') == 'complete') {
			        	$order_status = 'Complete'; 
			        	
			        }
			        else { 
			        	$order_status = $ordercoll->getData('status');  
			        	
			        }

			        $orderno = $ordercoll->getData('increment_id');
			        $orderid = $ordercoll->getData('entity_id');
			        $data[] = array('orderno'=>$orderno,'grand_total'=>$grand_total,'order_items'=>$order_items,'order_status'=>$order_status,'orderid'=>$orderid);
				}
			echo json_encode(array('status'=>'success','customer_id'=>$customerId,'data'=>$data));exit;
		 }
		//}
	       else { 
	       		echo json_encode(array('status'=>'failure','customer_id'=>$customerId,'data'=>$data));exit;
	       	}
	      
    }
    else
    {
    	echo json_encode(array('status'=>'failure','customer_id'=>$customerId,'data'=>$data));exit;
    }
	}

	public function OrderViewDetailAction()
    {	
   		$param = $this->getRequest()->getParam('orderid');
    	if($param) {
    	$order_item_detail = array();
    	$order = Mage::getModel('sales/order')->load($param);
		$attributeSetModel = Mage::getModel("eav/entity_attribute_set");
		$order_item = array();
		foreach ($order->getAllItems() as $item): 
			$product = Mage::getModel('catalog/product')->load($item->getProductId());				
				$attributeSetModel->load($product->getAttributeSetId());
				$attributeSetName = $attributeSetModel->getAttributeSetName();
				$metalWeight = '';
				if($attributeSetName != 'Rings'){
					$metalData = Mage::helper('stone')->getMetalData($item->getProductId());
					$metalWeight = $metalData['weight'];
				}else{
					$options1 = Mage::getModel('catalog/product_option')->getProductOptionCollection($product);
					foreach ($options1 as $option1) {					
						if ($option1->getType() === 'drop_down') {				
							$values1 = Mage::getSingleton('catalog/product_option_value')->getValuesCollection($option1);
							$ringData = $values1->getData();
							if($ringData[0]['title'] == $product->getRtsRingSize()){
								$metalWeight = $ringData[0]['metal_weight'];								
							}						
						}
					}
					if(empty($metalWeight)){
						$metalWeight = $product->getMetalWeight();
					}
				}
				$options = $item->getProductOptions();
				$img = Mage::helper('catalog/image')->init($product, 'small_image');
				
				if(strpos($img,"def_2"))
	            {
	           		$urlIm = $img->__toString();
	           	}
	           	else
	           	{
	           		$urlIm = $img->__toString();
	           	}
				//echo $urlIm;
				$product_img =  $urlIm;
				$product_name = $item->getName();
				$product_sku = $item->getSku();

				if(is_array($options) && is_array($options['options']) && !empty($options['options'])){ 
					foreach ($options['options'] as  $op){
						if($op['label'] == 'STONE QUALITY'){
							$stoneData = Mage::helper('stone')->getSideStoneData($item->getProductId(),$op['value']);
							if(isset($stoneData['totalweight'][0]) && $stoneData['totalweight'][0] != '')
							{ 
								$product_stoneweight = $stoneData['totalweight'][0].'cts';
							}
							$size_label = $op['value'];
						    $product_size =  $op['value'];
							}
							if($op['label'] == 'RING SIZE'){
								 $size_label = $op['value'];
								 $product_size =  $op['value'];
							}
						}
					}

					if($metalWeight != '')
					{ 
						$product_metalweight = number_format($metalWeight,2).'gms'; 
					}else{
						$objModel = Mage::getModel('catalog/product_option_value')->load($op['option_value']);
						$product_metalweight = number_format($objModel->getMetalWeight(),2).'gms';
					}

					$product_type = $attributeSetName;
					$product_price =$item->getPrice();
					$product_qty = $item->getQtyOrdered();
					$product_rawtotal = $item->getRowTotal();

					$order_item[] = array('product_img'=>$product_img,'product_name'=>$product_name,'product_sku'=>$product_sku,'product_stoneweight'=>$product_stoneweight,'product_size'=>$product_size,'product_metalweight'=>$product_metalweight,'product_type'=>$product_type,'product_price'=>$product_price,'product_rawtotal'=>$product_rawtotal,'product_qty'=>$product_qty);
		endforeach;
		//exit;
		//echo "<pre>";print_r($order->getData());
		$order_subtotal = $order->getSubtotal();
		$order_shippingamount = $order->getShippingAmount();
		$oder_taxamount =$order->getTaxAmount();
		$order_grandtotal = $order->getGrandTotal();
		$shiiping_address = $order->getShippingAddress()->format();
		$billing_address =  $order->getBillingAddress()->format();
		$shipping_description =$order->getShippingDescription();
		$order_date = $order->getCreatedAt();
		$order_date=date_create($order_date);
		$order_date = date_format($order_date,"F d, Y");

		$payment_method = 'Offline Payment'; //$order->getPayment()->getMethodInstance()->getTitle();
		$data[] = array('order_date'=>$order_date,'order_subtotal'=>$order_subtotal,'order_shippingamount'=>$order_shippingamount,'oder_taxamount'=>$oder_taxamount,'order_grandtotal'=>$order_grandtotal,'order_item' => $order_item ,'shiiping_address'=>$shiiping_address,'billing_address'=>$billing_address,'shipping_description'=>$shipping_description,'payment_method'=>$payment_method);
		echo json_encode(array('status'=>'success','data'=>$data));exit;
		}
		else
	    {
			echo json_encode(array('status'=>'failure','data'=>$data));exit;
		}
	}

	public function CancelOrderAction()
	{
		$store = Mage::app()->getStore();
		$orderId = $this->getRequest()->getParam('orderid');
        $order = Mage::getModel('sales/order')->load($orderId);
        if ($order->getId()) 
        {

			$order->cancel();
	        if ($status = Mage::helper('cancelorder/customer')->getCancelStatus($store)) {
	                    $order->addStatusHistoryComment('', $status)
	                          ->setIsCustomerNotified(1);
	        }
			$order->save();
			$order->sendOrderCancelEmail();
	   		 echo json_encode(array('status'=>'success','order_id'=>$orderId));exit;
        }
		else 
		{
           echo json_encode(array('status'=>'failure','order_id'=>$orderId));exit;
        }
	}

	
    public function downloadpdf111Action()
    {
           $order_id = $this->getRequest()->getParam('order_id');
           if($order_id) {
           $htmlBlock = Mage::app()->getLayout()->createBlock('catalog/product')
               ->setTemplate('sales/order/dmlinvoice_order_api.phtml')
               ->toHtml();
            $dompdf = new Dompdf();
            $customPaper = array(0,0,1317,1317);
            $dompdf->set_paper($customPaper);
            $dompdf->set_option('isHtml5ParserEnabled', true);
            $dompdf->loadHtml($htmlBlock);
            $dompdf->render();
            $file_to_save = 'pdf/'.$order_id.'.pdf';
			file_put_contents($file_to_save, $dompdf->output()); 
			$pdf_path = Mage::getStoreConfig(Mage_Core_Model_Url::XML_PATH_SECURE_URL).'pdf/'.$order_id.'.pdf';
			echo json_encode(array('status'=>'success','order_id'=>$order_id,'pdf'=>$pdf_path));exit;
			}
			else
			{
				echo json_encode(array('status'=>'failure','order_id'=>$order_id));exit;
			}
    }


    public function downloadpdfAction()
    {
        $order_id = $this->getRequest()->getParam('order_id');
           if($order_id) {
           	Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_SKIN);
           $htmlBlock = '<!DOCTYPE html>
					    <html lang="en" id="top" class="no-js">
					    <head>
					    <title>Print Order # '.$order_id.' | Dealermela</title>
					    <meta name="robots" content="INDEX,FOLLOW" />
					    <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet" />
					    <link href="https://fonts.googleapis.com/css?family=Oranienbaum" rel="stylesheet" />
					    <link rel="icon" href="'.Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_SKIN).'/frontend/base/default/favicon.ico" type="image/x-icon" />
					    <link rel="shortcut icon" href="'.Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_SKIN).'/frontend/base/default/favicon.ico" type="image/x-icon" />
					    <script type="text/javascript">
					    <![CDATA[
					    var loader_img="'.Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_SKIN).'/frontend/rwdnew/default/images/mgt_lazy_image_loader/loader.gif"
					    </script>
					    <link rel="stylesheet" type="text/css" href="'.Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_SKIN).'/frontend/rwdnew/default/css/styles.css" media="all" />
					    <link rel="stylesheet" type="text/css" href="'.Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_SKIN).'/frontend/rwdnew/default/css/responsive.css" media="all" />
					    <link rel="stylesheet" type="text/css" href="'.Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_SKIN).'/frontend/base/default/css/widgets.css" media="all" />
					    <link rel="stylesheet" type="text/css" href="'.Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_SKIN).'/frontend/rwdnew/default/css/print.css" media="print" />
					    <script type="text/javascript"  src="'.Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_JS).'/prototype/prototype.js"></script>
					    <script type="text/javascript"  src="'.Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_JS).'/mage/translate.js"></script>
					    <script type="text/javascript"  src="'.Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_JS).'/lib/ccard.js"></script>
					    <script type="text/javascript"  src="'.Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_JS).'/prototype/validation.js"></script>
					    <script type="text/javascript"  src="'.Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_JS).'/varien/js.js"></script>
					    <script type="text/javascript"  src="'.Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_JS).'/varien/weee.js"></script>
					    <link href="'.Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_SKIN).'/frontend/rwdnew/default/css/safari.css" rel="stylesheet" type="text/css" />
					    </head>
                    	<body class=" sales-order-print">
                    	<div class="print-container">
                        <section class="franchises-portal">';
			           $htmlBlock .= Mage::app()->getLayout()->createBlock('catalog/product')
			               ->setTemplate('sales/order/dmlinvoice_order_api.phtml')
			               ->toHtml();
			            $htmlBlock .= '</section>
                        </div></body></html>';
                        $path = "pdf/".$order_id.".html";
		                if (!file_exists($path)) { 
		                	$handle = fopen($path,'w+'); 
		                	fwrite($handle,$htmlBlock); fclose($handle); 
		                }
                		$fnlpath = Mage::getStoreConfig(Mage_Core_Model_Url::XML_PATH_SECURE_URL).$path;
            			echo json_encode(array('status'=>'success','order_id'=>$order_id,'pdf'=>$fnlpath));exit;
			}
			else
			{
				echo json_encode(array('status'=>'failure','order_id'=>$htmlBlock));exit;
			}
    }


}